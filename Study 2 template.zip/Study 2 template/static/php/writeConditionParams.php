<?php
	function writeInitializerJS($policy, $vis, $dataset) {
		try {
			$file_data = "var APP_DIRECTORY='" . $dataset . "';\n";
			$file_data .= "var QUERY_POLICY='" . $policy . "';\n";
			$file_data .= "var VIS_MODE='" . $vis . "';\n";

			$parent_dir = dirname(__DIR__);

			$upOne = realpath($parent_dir . '/..');

	        // $upOne = realpath($upOne . '/..');

			$condition_params_path = $upOne . '/condition_params.js';

			file_put_contents($condition_params_path, $file_data);

			echo "true";
		}
		catch (Exception $e) {
			echo "false";
		}
	}

	$msg = json_decode($_POST["data"], true);
    if ($msg["fxn"] == "writeInitializerJS") {
        writeInitializerJS($msg["policy"], $msg["vis"], $msg["dataset"]);
    }
?>
