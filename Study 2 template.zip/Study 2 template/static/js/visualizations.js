var class_A_color = "#2166ac";
var class_B_color = "#d6604d";
var target_color = "#5FF0AB";
var distribution_path_color = "#B4654A";
var distribution_path_opacity = 0.9;
var threshold_line_color = "#000";
var threshold_opacity_value = 0.85;
var threshold_line_stroke_width = "1.5px";
var xScale_shift = 25;
var xScale_line_shift = xScale_shift + 3.5;
var target_radius = 10;
var normal_radius = 4;
var target_selected_for_tutorial_i;

var tSNE_DATA_LOCATION = APP_DIRECTORY[3];

var json_http_tag = HTTP_TAG === "https://" ? "http://" : "https://"    // this is opposite normal. e.g. if HTTP_TAG is http, then this one is https and vice versa
var tSNE_DATA_LOCATION = json_http_tag + "cu-visualab.org/oracle_query/S2/tSNE_data/set" + APP_DIRECTORY[3] + "/scatter_data.json";


function create_numeric_plot(visualization_div, current_img_confidence) {
    var numeric_div = visualization_div.append("div").attr("id", "numeric_div")
        .style("position", "absolute")
        .style("left", "50px")
        .style("top", "70px");

    numeric_div.append("p")
        .attr("id", "phase_1_visualization_1")
        .html(function() {
            return "Certainty in Prediction";
        })
        .style("font-size", "12px");

    numeric_div.append("p")
        .attr("id", "phase_1_visualization")
        .html(function() {
            return parseInt(current_img_confidence * 100) + "%";
        })
        .style("font-size", "36px");
}
function create_scatter_plot_1(visualization_div, label, majority_label, target_i, tutorial_mode) {

    // Scatter Plot
    var target_selected_for_tutorial = false;

    // Params
    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 40
    };
    var width = 225 - margin.left - margin.right;
    var height = 225 - margin.top - margin.bottom;

    // SVG
    var svg = visualization_div.append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + (margin.left+5) + "," + margin.top + ")");

    // SCALES
    var xScale = d3.scaleLinear()
        .domain([0, 10])
        .range([0, width]);

    var yScale = d3.scaleLinear()
        .domain([0, 100])
        .range([height, 0]);

    // var yScale_text = ["Not Breed A: High Certainty", "Neutral", "Breed A: High Confidence"];
    var yScale_text = ["100% Not Breed A Certainty", "75%", "50%", "75% ", "100% Breed A Certainty"];
    var yScale_2 = d3.scalePoint()
        .domain(yScale_text)
        .range([height, 0]);


    // Threshold LINE
    svg.append("line")
        .attr("x1", function() {
            return xScale(0);
        })
        .attr("x2", function() {
            return xScale(3);
        })
        .attr("y1", function() {
            return yScale(50);
        })
        .attr("y2", function() {
            return yScale(50);
        })
        .style("stroke", threshold_line_color)
        .style("opacity", threshold_opacity_value)
        .style("stroke-dasharray", ("10, 3"))
        .style("stroke-width", threshold_line_stroke_width);

    // ************************************************
    // Generate data points
    var dataset = [];
    for (var i=0; i < study_1_data.length; i++) {
        var data_point = study_1_data[i]["img_confidence"];
        var majority_label = study_1_data[i]["majority_label"];
        data_point = dog_breed_key_inverse[majority_label] === 'dog_A' ? data_point : 1 - data_point;
        dataset.push({"confidence" : data_point*100, "majority_label" : majority_label});
    }
    // ************************************************

    // Y axis
    var y_axis = svg.append("g")
        .attr("class", "y axis")
        .call(d3.axisRight(yScale_2));

    y_axis.selectAll('.tick text')
        .attr('dx', function(d, i) {
            return (i === 2) ? 45 : 0;
        });

    // text label for the y axis
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left)
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .style("font-size", "12px")
        .text("Certainty in Prediction");

    // Create scatter points
    svg.selectAll(".dot")
        .data(dataset)
        .enter().append("circle")
        .attr("class", "dot")
        .attr("cx", function(d, i) {
            return xScale(0);
        })
        .attr("cy", function(d) {
            var random_sign = Math.random() > 0.5 ? -1 : 1;
            var conf = Math.min(Math.max(d.confidence + Math.random()*random_sign, 0), 100);
            var img_confidence = yScale(conf);
            return img_confidence;
        })
        .style("fill", function(d) {
            if (tutorial_mode) {
                return d.confidence > 50 ? class_A_color : class_B_color;
            }
            else {
                return (dog_breed_key_inverse[d.majority_label] === 'dog_A') ? class_A_color : class_B_color;
            }
        })
        .attr("r", function(d, i) {
            if (tutorial_mode) {
                if (i === target_i) {
                    return target_radius;
                }
                else {
                    return normal_radius;
                }
            }
            else {
                return i === target_i ? target_radius : normal_radius;
            }
        })
        .style("opacity", function(d, i) {
            return i === target_i ? 1.0 : 0.8;
        });

    createColorLegend(svg, width/3, 25);
}

function calculate_pmf(data, bins) {
    var lineData = [];

    var max_value = 100;
    var min_value = 0;

    lineData.push({
        "x": 0,
        "y": 0
    });
    var range = max_value - min_value;
    var step = range / parseFloat(bins);
    var bound = min_value;
    count_dict_pdf = {};
    for (var i = 0; i < bins; i++) {
        var temp_sum = 0;
        for (var j = 0; j < data.length; j++) {
            var x = data[j].confidence;
            if (bound < x && x <= (bound + step)) {
                temp_sum += 1;
            }
        }
        var probability = temp_sum / parseFloat(data.length);
        count_dict_pdf[bound] = probability

        lineData.push({
            "x": probability,
            "y": bound
        })
        bound += step;
    }
    lineData.push({
        "x": 0,
        "y": 100
    });

    return lineData;
}

function create_scatter_plot_2(visualization_div, label, majority_label, target_i, tutorial_mode) {
    var target_selected_for_tutorial = false;
    // Params
    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 40
    };
    var width = 355 - margin.left - margin.right;
    var height = 225 - margin.top - margin.bottom;

    // SVG
    var svg = visualization_div.append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + (margin.left+100) + "," + margin.top + ")");

    // SCALES
    var xScale = d3.scaleLinear()
        .domain([0, 10])
        .range([0, width]);

    var yScale = d3.scaleLinear()
        .domain([0, 100])
        .range([height - 10, -10]);

    var yScale_text = ["100% Not Breed A Certainty", "75%", "50%", "75% ", "100% Breed A Certainty"];
    var yScale_2 = d3.scalePoint()
        .domain(yScale_text)
        .range([height - 10, -10]);

    // Threshold LINE
    svg.append("line")
        .attr("x1", function() {
            return xScale(0);
        })
        .attr("x2", function() {
            return xScale(4);
        })
        .attr("y1", function() {
            return yScale(50);
        })
        .attr("y2", function() {
            return yScale(50);
        })
        .style("stroke", threshold_line_color)
        .style("opacity", threshold_opacity_value)
        .style("stroke-dasharray", ("10, 3"))
        .style("stroke-width", threshold_line_stroke_width);

    // ************************************************
    // Generate data points
    var dataset = [];
    for (var i=0; i < study_1_data.length; i++) {
        var data_point = study_1_data[i]["img_confidence"];
        var majority_label_i = study_1_data[i]["majority_label"];
        var data_point = dog_breed_key_inverse[majority_label_i] === 'dog_A' ? data_point : 1 - data_point;

        dataset.push({"confidence" : data_point*100, "majority_label" : majority_label_i});
    }
    // ************************************************

    var n_bins = 15;
    var lineData = calculate_pmf(dataset, n_bins);

    lineDataVals = [];
    for (var i = 0; i < lineData.length; i++) {
        lineDataVals.push(lineData[i].x);
    };

    var min_val = Math.min(...lineDataVals);
    var max_val = Math.max(...lineDataVals);

    var xScalePDF = d3.scaleLinear()
        .domain([0, 0.3])
        .range([0, width / 3]);

    var xScaleAxis = d3.scaleLinear()
        .domain([0, 1])
        .range([0, width / 2]);

    var color = d3.scaleLinear()
        .domain([0, n_bins])
        .range([class_A_color, class_B_color]);

    // Prob line
    // ************************************************
    var lineFunction = d3.line()
        .x(function(d) {
            return xScalePDF(d.x) + xScale_line_shift;
        })
        .y(function(d) {
            return yScale(d.y);
        })
        .curve(d3.curveCardinal);

    // https://www.freshconsulting.com/d3-js-gradients-the-easy-way/
    var defs = svg.append("defs");

    var gradient = defs.append("linearGradient")
        .attr("id", "svgGradient")
        .attr("x1", "100%")
        .attr("x2", "100%")
        .attr("y1", "0%")
        .attr("y2", "100%");

    gradient.append("stop")
        .attr('class', 'start')
        .attr("offset", "0%")
        .attr("stop-color", class_A_color)
        .attr("stop-opacity", 1);

    gradient.append("stop")
        .attr('class', 'end')
        .attr("offset", "100%")
        .attr("stop-color", class_B_color)
        .attr("stop-opacity", 1);

    var lineGraph = svg.append("path")
        .attr("d", lineFunction(lineData))
        // .attr("stroke", distribution_path_color)
        .attr("stroke", "url(#svgGradient)")
        .attr("opacity", distribution_path_opacity)
        .attr("stroke-width", 2)
        .attr("fill", "none");
    // ************************************************

    // // X axis
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(" + xScale_shift + "," + (height) + ")")
        .call(d3.axisBottom(xScaleAxis).ticks(2));

    // // Y axis
    // svg.append("g")
    //     .attr("class", "y axis")
    //     .call(d3.axisLeft(yScale));

    var y_axis = svg.append("g")
        .attr("class", "y axis")
        .call(d3.axisLeft(yScale_2));

    // y_axis.selectAll('.tick text')
    //     .attr('dx', function(d, i) {
    //         return 85;
    //         // return (i === 2) ? 75 : ;
    //     })

    // text label for the x axis
    svg.append("text")
        .attr("id", "x_axis_label")
        .attr("transform", "translate(" + (width / 2.5 - 5) + " ," + (height + margin.top+8) + ")")
        .style("text-anchor", "middle")
        .style("font-size", "12px")
        .text("Proportion of Predictions");

    // text label for the y axis
    // svg.append("text")
    //     .attr("transform", "rotate(-90)")
    //     .attr("y", 0 - margin.left - 15)
    //     .attr("x", 0 - (height / 2))
    //     .attr("dy", "1em")
    //     .style("text-anchor", "middle")
    //     .style("font-size", "12px")
    //     .text("Certainty in Prediction");

    // Create scatter points
    svg.selectAll(".dot")
        .data(dataset)
        .enter().append("circle")
        .attr("class", "dot")
        .attr("cx", function(d, i) {
            return xScale(0);
        })
        .attr("cy", function(d) {
            var random_sign = Math.random() > 0.5 ? -1 : 1;
            var conf = Math.min(Math.max(d.confidence + Math.random()*random_sign, 0), 100);
            var img_confidence = yScale(conf);
            return img_confidence;
        })
        // Chnage the color of dots if the data point is higher than the 50% border line
        .style("fill", function(d) {
            if (tutorial_mode) {
                return d.confidence > 50 ? class_A_color : class_B_color;
            }
            else {
                return (dog_breed_key_inverse[d.majority_label] === 'dog_A') ? class_A_color : class_B_color;
            }
        })
        .attr("r", function(d, i) {
            if (tutorial_mode) {
                if (i === target_i) {
                    return target_radius;
                }
                else {
                    return normal_radius;
                }
            }
            else {
                return i === target_i ? target_radius : normal_radius;
            }
        })
        .style("opacity", function(d, i) {
            return i === target_i ? 1.0 : 0.8;
        });

    var legendSVG_div = d3.select("panel").append("div").attr("id", "legendSVG_div")
        .style("position", "absolute")
        .style("top", "30px")
        .style("left", "50%");

    var legendSVG = legendSVG_div.append("svg").attr("id", "legendSVG")
        .append("g").attr("transform", "translate(0, 20)");

    createColorLegend(svg, width*0.35, 0);
}

function create_bar_chart_1(visualization_div, label, majority_label, current_img_confidence) {
    // Single-bar BARCHART
    // Parameters
    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 30
    };
    var width = 245 - margin.left - margin.right;
    var height = 225 - margin.top - margin.bottom;

    // SVG
    var svg = visualization_div.append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + (margin.left + 10) + "," + margin.top + ")");

    current_img_confidence = dog_breed_key_inverse[majority_label] === "dog_A" ? current_img_confidence : 1 - current_img_confidence;
    var dataset = [{
        label: "Dog Breed A",
        value: current_img_confidence * 100
    }]

    // Scales
    var xScale = d3.scaleBand()
        .domain(dataset.map(function(d) {
            return d.label;
        }))
        .range([0, width])
        .padding(0.5);

    var yScale = d3.scaleLinear()
        .domain([0, 100])
        .range([height, 0]);

    // Create X axis
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(xScale));

    // Create Y axis
    svg.append("g")
        .attr("class", "y axis")
        .call(d3.axisLeft(yScale));

    // text label for the y axis
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left - 10)
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .style("font-size", "12px")
        .text("Certainty in Prediction");

    // Add bars
    svg.selectAll(".bar")
        .data(dataset)
        .enter().append("rect")
        .attr("class", "bar")
        .style("fill", class_A_color)
        .attr("x", function(d) {
            return xScale(d.label);
        })
        .attr("y", function(d) {
            return yScale(d.value);
        })
        .attr("width", xScale.bandwidth())
        .attr("height", function(d) {
            return height - yScale(d.value);
        });
}


function create_bar_chart_2(visualization_div, label, majority_label, current_img_confidence) {

    current_img_confidence = dog_breed_key_inverse[majority_label] === "dog_A" ? current_img_confidence : 1 - current_img_confidence;

    // 2-BAR BARCHART
    // Parameters
    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 30
    };
    var width = 245 - margin.left - margin.right;
    var height = 225 - margin.top - margin.bottom;

    // SVG
    var svg = visualization_div.append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + (margin.left + 10) + "," + margin.top + ")");

    // Generate data points
    var probA = current_img_confidence * 100;
    var probB = 100 - probA;
    var dataset = [probA, probB];

    var dataset = [{
            label: "Dog Breed A",
            value: probA
        },
        {
            label: "Not Dog Breed A",
            value: probB
        }
    ]

    // Create Scales
    var xScale = d3.scaleBand()
        .domain(dataset.map(function(d) {
            return d.label;
        }))
        .range([0, width])
        .padding(0.5);

    var yScale = d3.scaleLinear()
        .domain([0, 100])
        .range([height, 0]);

    // Create X axis
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(xScale));

    // Create Y axis
    svg.append("g")
        .attr("class", "y axis")
        .call(d3.axisLeft(yScale));

    // text label for the y axis
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left - 10)
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .style("font-size", "12px")
        .text("Certainty in Prediction");

    // Add bars
    svg.selectAll(".bar")
        .data(dataset)
        .enter().append("rect")
        .attr("class", "bar")
        .style("fill", function(d, i) {
            return (i === 0) ? class_A_color : class_B_color;
        })
        .attr("x", function(d) {
            return xScale(d.label);
        })
        .attr("y", function(d) {
            return yScale(d.value);
        })
        .attr("width", xScale.bandwidth())
        .attr("height", function(d) {
            return height - yScale(d.value);
        });
}

function create_tSNE_plot(visualization_div, label, target, majority_label, tutorial_mode) {
    var target_id = target.split("/")
    var last_id = target_id.length - 1;
    target_id = target_id[last_id].replace(".png", "");

    if (target_id.includes("dog_A")) {
        target_id = target_id.replace("dog_A", dog_breed_key["dog_A"]);
    }
    else {
        target_id = target_id.replace("dog_B", dog_breed_key["dog_B"]);
    }

    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 40
    };

    // rest of vars
    var img_dim = 40;
    var target_img_dim = img_dim;
    var marker_x = 10;
    var marker_y = 10;
    var marker_size = 10;
    var taken_locations = [];
    var groups_to_remove = [];
    var all_ids = [];
    var image_selected = false;
    var selected_image = undefined;

    var decision_boundary_ON = false;

    // Params
    var margin = {
        top: 20,
        right: 20,
        bottom: 30,
        left: 40
    };

    var container_width = 405 - margin.left - margin.right;
    var container_height = 255 - margin.top - margin.bottom;

    var width = 245 - margin.left - margin.right;
    var height = 225 - margin.top - margin.bottom;

    // SVG
    var svg = visualization_div.append("svg")
        .attr("width", container_width + margin.left + margin.right)
        .attr("height", container_height + margin.top + margin.bottom)
        .append("g")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .attr("transform", "translate(" + margin.left + "," + (margin.top - 10) + ")");


    d3.json(tSNE_DATA_LOCATION, function(json) {
        update(json);
    });

    function update(json) {
        var target_selected_for_tutorial = false;
        var target_selected_for_tutorial_i = undefined;
        var data = json.children;
        for (var i = 0; i < data.length; i++) {
            data[i].img = data[i].img.replace("../", "static/");
        }

        var x_min = json.data_params.x_min;
        var x_max = json.data_params.x_max;
        var y_min = json.data_params.y_min;
        var y_max = json.data_params.y_max;
        var max_width = x_max - x_min;

        var xScale = d3.scaleLinear()
            .domain([x_min, x_max])
            .range([0, width]);

        var yScale = d3.scaleLinear()
            .domain([y_min, y_max])
            .range([0, height]);

        var xScaleAxis = d3.scaleLinear()
            .domain([0, 1])
            .range([0, width * 0.75]);

        var yScaleAxis = d3.scaleLinear()
            .domain([0, 1])
            .range([width * 0.70, 0]);

        // Create scatter points
        svg.selectAll(".dot")
            .data(data)
            .enter().append("circle")
            .attr("class", "dot")
            .attr("cx", function(d, i) {
                return xScale(d.x);
            })
            .attr("cy", function(d) {
                return yScale(d.y)
            })
            // Chnage the color of dots if the data point is higher than the 50% border line
            .style("fill", function(d, i) {
                if (tutorial_mode && !target_selected_for_tutorial) {
                    if (Math.random() < 0.1) {
                        target_selected_for_tutorial = true;
                        target_selected_for_tutorial_i = i;
                        return majority_label === "dog_A" ? class_A_color : class_B_color;
                    }
                }
                return dog_breed_key_inverse[d.label] === "dog_A" ? class_A_color : class_B_color;
            })
            .style("opacity", function(d, i) {
                if (tutorial_mode) {
                    if (i === target_selected_for_tutorial_i) {
                        return 1.0;
                    }
                }
                return d.img.includes(target_id) ? 1.0 : 0.75;
            })
            .attr("r", function(d, i) {
                if (tutorial_mode) {
                    if (i === target_selected_for_tutorial_i) {
                        return target_radius;
                    }
                }
                return d.img.includes(target_id) ? target_radius : normal_radius;
            });

        // X axis
        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + (height + 5) + ")")
            .call(d3.axisBottom(xScale));

        // text label for the x axis
        svg.append("text")
            .attr("id", "x_axis_label")
            .attr("transform", "translate(" + (width / 2) + " ," + (height + 34) + ")")
            .style("text-anchor", "middle")
            .style("font-size", "12px")
            .text("Similarity in Feature 1");

        // Y axis
        svg.append("g")
            .attr("class", "y axis")
            .attr("transform", "translate(-5,0)")
            .call(d3.axisLeft(yScale));

        // text label for the y axis
        svg.append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 0 - margin.left - 2)
            .attr("x", 0 - (height / 2))
            .attr("dy", "1em")
            .style("text-anchor", "middle")
            .style("font-size", "12px")
            .text("Similarity in Feature 2");

        createColorLegend(svg, width, 0);
    }
}

function createColorLegend(svg, width, height) {
    // color key
    var color_key_g = svg.append("g")
        .attr("id", "color_key_g")
        .attr("transform", "translate("+ (width + 20) +", " + height + ")");

    var breed_A_key_g = color_key_g.append("g").attr("id", "breed_A_key_g");

    breed_A_key_g.append("circle")
        .attr("id", "breed_A_key_circle")
        .attr("class", "dot")
        // Chnage the color of dots if the data point is higher than the 50% border line
        .style("fill", class_A_color)
        .style("opacity", 0.75)
        .attr("r", normal_radius);

    breed_A_key_g.append("text")
        .attr("x", "10")
        .attr("y", "4")
        .style("text-anchor", "left")
        .style("font-size", "12px")
        .text("Dog Breed A");


    var breed_B_key_g = color_key_g.append("g").attr("id", "breed_B_key_g").attr("transform", "translate(0, 20)");

    breed_B_key_g.append("circle")
        .attr("id", "breed_B_key_circle")
        .attr("class", "dot")
        // Chnage the color of dots if the data point is higher than the 50% border line
        .style("fill", class_B_color)
        .style("opacity", 0.75)
        .attr("r", normal_radius);

    breed_B_key_g.append("text")
        .attr("x", "10")
        .attr("y", "4")
        .style("text-anchor", "left")
        .style("font-size", "12px")
        .text("Not Dog Breed A");
}
