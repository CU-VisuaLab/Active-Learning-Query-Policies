var sessionTime = 0;
var dpi = 0;
var inchesToDisplay = 30;
var startTime = 0;
var endTime = 0;
var trialStartTime = 0;
var resp = "none";
var numCircles = 1;
var iters = 0;
var cvd = "n";
var trial_i = 0;
var attention_check_i = 0;
var current_img;
var current_img_confidence;
var current_img_correctness;
var study_running = true;
var dog_breed_key;
var dog_breed_key_raw;
var dog_breed_key_inverse;
var study_image_div_shift = "-140px";
var tSNE_study_image_div_shift = "-160px";
var majority_label;

// Display parameters
var colorType = null;
var baseStep = 0.5;
var background = "white";

var LARGEST_SIZE = visualAngleToPixels(6.0, 30, 96);

// This is something that is important

// Layout parameters
var positions = [];
var proximity = 0;
var respInt;
var whiteInt;
var layoutType = "grid";



function initializeVariables() {
    sampled_indices = [];
    positions = [];
    trial_i = 0;
}

function get_PHP_info(callBack) {
    var send_data = {
        "fxn" : "load_information",
        "dataset"   : APP_DIRECTORY
    }
    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/
    $.post("static/php/study_initializer.php", {data : dataString},
    function(receive_data) {
        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = false;
        }
        callBack(data);
    });
}

function init_PHP(main_callBack) {
    get_PHP_info(function(config_callBack) {
        if (config_callBack["success"] === true) {
            dog_breed_key_raw = config_callBack.data.class_breed_info;
            dog_breed_key_raw = dog_breed_key_raw.split("\n");
            dog_breed_key = {};
            for (var i=0; i<2; i++) {
                var dog = dog_breed_key_raw[i].split(" : ");
                var key = dog[0];
                var val = dog[1];
                dog_breed_key[key] = val;
            }
            console.log(dog_breed_key);
            dog_breed_key_inverse = {}
            for (var dog_key in dog_breed_key) {
                var dog_val = dog_breed_key[dog_key];
                dog_breed_key_inverse[dog_val] = dog_key;
            }
            console.log(dog_breed_key_inverse);
            main_callBack(true);
        }
        else {
            main_callBack(false);
        }
    });
}



function initializeAll() {
    var CURRENT_PHASE = "training";
    initializeVariables();
    init_PHP(function(main_callBack) {
        if (main_callBack) {
            getUserId(function(callBack) {
                if (callBack === "success") {
                    initializeData(CURRENT_PHASE, function(dataCallback) {
                        initializeStudy();
                    });
                }
            });
        }
        else {
            console.log("PHP Fail!");
        }
    });
}

$(function() {

    if (IN_DEVELOPMENT && EXPLORE_VISUALIZATIONS) {

        var vis_selection_div = d3.select("body").append("div").attr("id", "vis_selection_div")
            .style("position", "absolute")
            .style("left", "100px")
            .style("top", "150px");

        vis_selection_div.append('h1')
            .html("Developer Options")
            .style("font-size", "24px");

        vis_selection_div.append('h2')
            .html("Visualizations")
            .style("font-size", "16px");

        var vis_selection = vis_selection_div
            .append("select")
            .attr("id", "vis_selection")
            .attr("name", "visualizations")
            .on("change", function(d) {
                VIS_MODE = this.value;
                QUERY_POLICY = d3.select("#policy_selection").node().value;
                initializeAll();
            });

        vis_selection.selectAll("option")
            .data(visualization_modes).enter()
            .append("option")
            .attr("value", function(d) {
                return d;
            })
            .attr("name" , function(d) {
                return d;
            })
            .text(function(d) { return d; });

        vis_selection_div.append('h2')
            .html("Policies")
            .style("font-size", "16px");

        var policy_selection = vis_selection_div
            .append("select")
            .attr("id", "policy_selection")
            .attr("name", "policies")
            .on("change", function(d) {
                QUERY_POLICY = this.value;
                VIS_MODE = d3.select("#vis_selection").node().value;
                initializeAll();
            });

        policy_selection.selectAll("option")
            .data(query_policies).enter()
            .append("option")
            .attr("value", function(d) {
                return d.policy;
            })
            .attr("name" , function(d) {
                return d.policy;
            })
            .text(function(d) { return d.name; });

    }

    initializeAll();
});


//--------------------------------------------------------------- Utility Functions ---------------------------------------------------------->

function initializeStudy() {
    if (IN_DEVELOPMENT) {
        console.log("User id: " + userId);
    }

    // Extract the demographic form parameters
    $("#instructions_panel").remove();
    document.getElementById("test_panel").style.visibility = 'visible';

    // Fetch the DPI and id
    startSession();
    dpi = $("#dpi").height();

    // Fetch the configs
    colorType = COLORTYPE['Lab'];
    proximity = visualAngleToPixels(5, inchesToDisplay, dpi);

    // Leftovers from social media study
    baseStep = 0.33;
    background = "white";
    $("document").css("background-color", background);

    // Parse command line argument (important)
    var urlArgs = window.location.search;

    // Set the panel widget
    var nc = 1;
    var nr = 1;
    var panelW = (layoutType == "grid") ? (2 * proximity + 2 * GRID_PAD + LARGEST_SIZE) * nc :
        2 * (proximity + 2 * LARGEST_SIZE);

    var panelH = (proximity + LARGEST_SIZE);
    $("#stimuli").width(panelW);
    $("#stimuli").height(panelH);
    $("#stimuli").css("padding-top", "100px");

    $("#panel").width("100%");
    // $("#panel").width(panelW);
    $("#panel").height(panelH + 100);
    $("#panel").width($("#panel").width());

    // Instantiate the keyboard input
    window.addEventListener("keyup", function (event) {
        if (event.defaultPrevented) {
            return; // Do nothing if the event was already processed
        }

        switch (event.key) {
        case "f":
        case "F":
            user_response = "Keep";
            adapt(true);
            break;
        case "j":
        case "J":
            user_response = "Change";
            adapt(true);
            break;
        default:
            return; // Quit when this doesn't handle the key event.
        }

        // Cancel the default action to avoid it being handled twice
        event.preventDefault();
    }, true);

    // Instantiate the study
    trialStartTime = new Date();
    runStudy();
}



function shuffle_images(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

function updateProgress() {
    $("#progress").html("Completed " + trial_i + " / " + TRIALS_PER_PARTICIPANT + " trials");
}


function nextImage() {

    startTime = new Date();

    // remove previous image
    d3.select("#study_image").remove();
    d3.select("#phase_1_vis_descript").remove();
    d3.select("#phase_1_visualization").remove();
    d3.select("#visualization_div").remove();

    // Select next image from list
    var current_img_i = study_1_data[trial_i];

    // Get current image location
    current_img = current_img_i['path'];

    current_img = current_img.split("cu-visualab.org")[1];
    current_img = HTTP_TAG + "cu-visualab.org" + current_img;

    // Confidence
    var current_img_confidence = current_img_i["img_confidence"];

    // Correctness
    var current_img_correctness = current_img_i["img_correctness"];

    // Majority Label
    majority_label = current_img_i["majority_label"];

    // Image ID
    var current_img_id = extract_image_name(current_img_i["img_name"]);

    d3.select("#study_image_div").style("opacity", 0.0);

    // Append new image
    d3.select("#study_image_div").append("img")
        .attr("id", "study_image")
        .attr("src", current_img);

    // Create visualization div
    if (VIS_MODE !== "none") {
        var visualization_div = d3.select("#panel").append("div")
            .attr("id", "visualization_div")
            .style("position", "absolute")
            .style("top", "30px")
            .style("left", "50%")
            .style("opacity", 0.0);
    }

    // Append text
    // var label = extract_label(current_img);
    var label = (dog_breed_key_inverse[majority_label] === "dog_A") ? "Dog Breed A" : "Not Dog Breed A";

    d3.select("#study_image_classification").html("System Classification<br>"+label);

    // UPDATE INSTRUCTIONS
    // ----------------------------------------------------------------------
    if (VIS_MODE === "none") {
        // TODO: Remove before deployment
        console.log("Nothing to visualize!");

        // Adjust image position
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", 0);
    }
    else if (VIS_MODE === "numeric") {
        console.log("Numeric visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the information to the right of the image to aid your decision.<br>";
                description += "The number corresponds to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS (just a number in this case)
        // ---------------------------------------------
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);

        create_numeric_plot(visualization_div, current_img_confidence);

        // ---------------------------------------------
    }
    else if (VIS_MODE === "bar_chart_1") {
        console.log("Bar chart visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the visualization to the right of the image to aid your decision.<br>";
                description += "The bar corresponds to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        // Adjust image position
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_bar_chart_1(visualization_div, label, majority_label, current_img_confidence);
        // ----------------------------------------
    }
    else if (VIS_MODE === "bar_chart_2") {
        console.log("Bar chart 2 visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the visualization to the right of the image to aid your decision.<br>";
                description += "The bars correspond to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_bar_chart_2(visualization_div, label, majority_label, current_img_confidence);
        // ----------------------------------------
    }
    else if (VIS_MODE === "scatter_plot_1") {
        console.log("Scatter 1 visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the visualization to the right of the image to aid your decision.<br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The vertical distance in either direction away from the dotted-line represent the system's certainty in its classification.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_scatter_plot_1(visualization_div, label, majority_label, trial_i, false);
        // ----------------------------------------
    }
    else if (VIS_MODE === "scatter_plot_2") {
        console.log("Scatter 2 visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the visualization to the right of the image to aid your decision.<br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The vertical distance in either direction away from the dotted-line represent the system's certainty in its classification.<br>";
                description += "The curve over the dots represents the proportion of images for a given level of the system's certainty in classification.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_scatter_plot_2(visualization_div, label, majority_label, trial_i, false);
        // ----------------------------------------
    }
    else if (VIS_MODE === "tSNE") {
        console.log("tSNE visualization!");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#phase_1_visualization_description").append("p")
            .attr("id", "phase_1_vis_descript")
            .html(function() {
                var description = "You may use the visualization to the right of the image to aid your decision. <br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The neighboring dots and their classifications may aid your decision of the current image's true classification. <br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#study_image_div")
            .style("position", "relative")
            .style("left", tSNE_study_image_div_shift);
        // Create bar chart
        create_tSNE_plot(visualization_div, label, current_img, majority_label);
        // ----------------------------------------
    }
    // ----------------------------------------------------------------------

    updateProgress();
}

function startSession() {
    var date = new Date();
    sessionTime = (date.getMonth() + 1) + "_" + date.getDate() + "_" + date.getHours() + "_" + date.getMinutes() + "_" + date.getSeconds();
    return true;
};



function logResponse() {

    if (adaptationScreenOn) {
        console.log("Adaption screen on. Wait to click.");
        return;
    }

    if (!study_running) {
        return;
    }

    // Clear interval
    clearInterval(respInt);

    // Write data
    writeData_phase_1(startTime, endTime, majority_label);

    trial_i++;

    if (trial_i === TRIALS_PER_PARTICIPANT) {
        d3.select('body').transition().duration(500).style("opacity", 0.4);
        study_running = false;
        updateProgress();
        setTimeout(function() {
            query = window.location.search;
            if (query.substring(0, 1) == '?') {
                query = query.substring(1);
            }
            pushStudyResultsToDatabase("phase_1", query);
            alert("Training Complete! Click 'OK' to continue onto next phase.");
            return;
        }, 500);
    }
    else if (!study_running) {
        return;
    }
    else {
        // Generate the next image
        adaptationScreen("#study_image_div");
    }
};

function runStudy() {

    // Reset the response
    clearInterval(respInt);

    // Select Photo
    nextImage();
    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select("#study_image_div")
            .transition().duration(1000)
            .style("opacity", 1.0);

        d3.select("#visualization_div")
            .transition().duration(1000)
            .style("opacity", 1.0);
    }, 800);
};
