var IN_DEVELOPMENT = false;

function gup(name) {
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var tmpURL = window.location.href;
    var results = regex.exec(tmpURL);

    if (results == null) {
        return "";
    } else {
        return results[1];
    }
}

function decode(strToDecode) {
    var encoded = strToDecode;
    return unescape(encoded.replace(/\+/g, " "));
}

function startExp() {
    var userId = gup('assignmentId');
    var turkId = gup('workerId');
    // TODO: If your page doesn't require color vision, redirect to either "distance_page.html" or "tutorial.html" instead

    if (IN_DEVELOPMENT) {
        console.log("startExp()")
        console.log("USERID: " + userId);
        console.log("TURKID: " + turkId);
        console.log("\n\n");
    }

    // Go to next page
    window.open("tutorial.php?" + turkId + "&" + location.search.substring(1));
}

function load_part_2() {
    document.getElementById('assignmentId').value = gup('assignmentId');
    document.getElementById('workerId').value = gup('workerId');

    // Check if the worker is PREVIEWING the HIT or if they've ACCEPTED the HIT
    if (gup('assignmentId') == "ASSIGNMENT_ID_NOT_AVAILABLE")
    {
        document.getElementById('readyBtn').value="PLEASE ACCEPT HIT BEFORE CONTINUING";
        document.getElementById('readyBtn').disabled = "disabled";
        document.getElementById('commentsform').innerHTML="<p>You cannot submit while previewing.</p>";
        // If we're previewing, disable the button and give it a helpful message
        document.getElementById('submitButton').disabled = "disabled";
        document.getElementById('submitButton').value = "You must ACCEPT the HIT before you can submit the results.";
    }
    else {
        var form = document.getElementById('mturk_form');
        if (document.referrer && ( document.referrer.indexOf('workersandbox') != -1) ) {
            form.action = "//workersandbox.mturk.com/mturk/externalSubmit";
        }
    }
}

function checkTaken() {
    document.getElementById('jscheck').innerHTML = "<p></p>";
    document.getElementById('readyBtn').disabled = "";
    $.ajax({
        url: 'static/php/utils.php',
        data: {action: 'hasTaken'},
        type: 'post',
        success: function(result) {
            var user_already_taken_study = $.parseJSON(result);
            if (user_already_taken_study === "true") {
                if (!IN_DEVELOPMENT) {
                    document.getElementById('readyBtn').disabled = "disabled";
                }
                document.getElementById('commentsform').innerHTML = "<h3>Sorry, but our records indicate that someone with your IP has already taken this test.</h3>";
                load_part_2();
            }
        }
    });
}

$(function() {
    if (window.attachEvent) {
        window.attachEvent('onload', checkTaken);
    }
    else if (window.addEventListener) {
        window.addEventListener('load', checkTaken, false);
    }
    else {
        document.addEventListener('load', checkTaken, false);
    }
});
