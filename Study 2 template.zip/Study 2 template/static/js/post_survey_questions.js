// Code to write a series of results to a CSV
var questionnaireResponseList = [];
var likertAnswers = [];
var num_required = 13;
var form_ready_to_submit = false;

function styleIt(i) {
    d3.select("#likert_ul_"+i).transition().style("background-color", "#ccffcc");
}

function checkFormComplete() {
    var num_checked = 0;
    for (var i=1; i < num_required+1; i++) {
        var radios = document.getElementsByName('likert_questionnaire_'+i);

        var at_least_one_checked = false;
        for (var j = 0, length = radios.length; j < length; j++)
        {
            if (radios[j].checked)
            {
                at_least_one_checked = true;
                num_checked++;
            }
        }

        if (at_least_one_checked) {
            d3.select("#likert_ul_"+i).transition().style("background-color", "#ccffcc");
        }
        else {
            d3.select("#likert_ul_"+i).transition().style("background-color", "#ffcccc");
        }
    }

    if (num_checked < num_required) {
        alert("Please complete the form to continue.");
        form_ready_to_submit = false;
        return false;
    }
    else {
        form_ready_to_submit = true;
        return true;
    }
}

function preSubmit() {

    if (checkFormComplete()) {
        // Set userId
        getUserId(function(callBack) {
            if (callBack === "success") {
                $("#userId").val(userId);
                submitQuestionnaireForm();
                // $("#questionnaireForm").submit();
                return true;
            }
        });
    }
    else {
        return false;
    }
}


function writeQuestionnaireData() {
    /*
        CREATE TABLE questionnaire_data (
            userId INT(10),
            Q1 INT(10),
            Q2 INT(10),
            Q3 INT(10),
            Q4 INT(10),
            Q5 INT(10),
            Q6 INT(10),
            Q7 INT(10),
            Q8 INT(10),
            Q9 INT(10),
            Q10 INT(10),
            Q11 INT(10),
            Q12 INT(10),
            Q13 INT(10)
        );
    */
    var outputLine = [];

    // participant id
    outputLine.push(userId);

    for (var i=1; i < num_required+1; i++) {
        var radios = document.getElementsByName('likert_questionnaire_'+i);
        for (var j = 0; j < radios.length; j++)
        {
            if (radios[j].checked)
            {
                outputLine.push("'" + (j+1) + "'");
            }
        }
    }

    // Write out the file
    var outputData = ("(" + outputLine.join(",") + ")");

    console.log(outputData);

    responseList.push(outputData);
};


function submitQuestionnaireForm() {

    writeQuestionnaireData();

    /// Write the study end time
    var ajax_succesful = false;
    $("#responses").val(responseList.join(","));
    $.ajax({
        type: 'POST',
        url: 'static/php/submitQuestionnaire.php',
        data: $("#responseForm").serialize(),
        complete: function(e) {
            console.log(e);
            ajax_succesful = true;
            window.location = "demographics.php";
        }
    });
    return ajax_succesful;
}

$(function() {
    var questionnaire_form_div = d3.select("#questionnaireForm").append("div")
        .attr("id", "submit")
        .attr("class", "buttons");

    questionnaire_form_div.append("input")
        .attr("id", "submitButton")
        .attr("type", "button")
        .attr("value", "Submit")
        .on("click", function() {
            preSubmit();
        })
});
