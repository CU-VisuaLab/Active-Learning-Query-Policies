<?php
ini_set('display_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL ^ E_DEPRECATED);

function hasTaken()
{
    try {
        $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");

        if (!$db) {
            throw new Exception('Error connecting to mysql');
        }

        $result = mysqli_query($db, 'SELECT count(*) as num from mli_test.user_data where ip="' . $_SERVER['REMOTE_ADDR'] . '";');

        if (!$result) {
            die('Trouble:' . mysqli_error($db) . '<br \>');
        }

        $row = mysqli_fetch_assoc($result);

        if (!$row || $row['num'] == 0) {
            echo json_encode("false");
        } else {
            echo json_encode("true");
        }

        mysqli_close($db);
    }
    catch (Exception $e) {
        echo json_encode("true");
    }
}

function logUserToDB($projectorer)
{
    $study_num = "A1"; // set: example "A1"

    $time1 = date('Y-m-d H:i:s', time());
    $time2 = date('Y-m-d H:i:s', time());
    // Insert into the id database the id, projectorer, ip, start
    $query = 'INSERT INTO mli_test.user_data VALUES (0,';
    $query .= $projectorer . ','; // TURK ID
    $query .= '"' . $_SERVER['REMOTE_ADDR'] . '",'; // IP
    $query .= '"' . $study_num . '",';
    $query .= '"' . $time1 . '", "' . $time2 . '");'; // START AND STOP TIME

    try {
        $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");
        if (!$db) {
            throw new Exception('Error connecting to mysql');
        }

        $result = mysqli_query($db, $query);
        if (!$result) {
            die('Trouble:' . mysqli_error($db) . $query . '<br \>');
        }

        mysqli_close($db);
    }
    catch (Exception $e) {
        echo 'Troubles:<br \>';
    }
}

function fetchUserId()
{
    // Fetch the user ID from the general db
    $query = 'SELECT MAX(userId) as num FROM mli_test.user_data;';

    try {
        $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");
        if (!$db) {
            throw new Exception('Error connecting to mysql');
        }
        $result = mysqli_query($db, $query);
        if (!$result) {
            die('Trouble:' . mysqli_error($db) . $query . '<br \>');
        }
        $row = mysqli_fetch_assoc($result);

		echo json_encode($row['num']);

        mysqli_close($db);
    }
    catch (Exception $e) {
        die('Trouble:' . mysqli_error($db) . '<br \>');
        echo 'Troubles:<br \>';
        echo $e . '<br \>';
    }
}

if (isset($_POST['action']) && !empty($_POST['action'])) {
    $action = $_POST['action'];

    switch ($action) {
        case 'hasTaken':
            hasTaken();
            break;
        case 'fetchUserId':
            fetchUserId();
            break;
    }
}
?>
