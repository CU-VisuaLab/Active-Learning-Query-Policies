<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="static/css/jnd_test.css" />
        <script type="text/javascript" src="static/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="static/js/initializer.js"></script>
        <script type="text/javascript" src="static/js/demographics.js"></script>
        <title>Evaluating Active Learning Oracle Querying Policies</title>
    </head>
    <body>
        <div class="centralPanel">
            <p class="label">For the purposes of our study, we need to collect some personal information. The information will remain anonymous and is for statistical analysis purposes only. Please fill out the fields below and click submit to complete the study.</p>
            <form id="demoForm" class="label" method="post" onSubmit="return writeResponses();" action="thankyou.html">
                <input type="hidden" name="userId" id="userId"/>
                <table cellpadding="10px">
                    <tr>
                        <td>
                            Age:
                        </td>
                        <td>
                            <input id="age" name="age" type="number" value="0" min="18" max="65" class="numBox"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Occupation:
                        </td>
                        <td colspan="2">
                            <input id="occupation" name="occupation" type="text" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Gender:
                        </td>
                        <td>
                            <input type="radio" name="gender" value="Male"/>Male
                        </td>
                        <td>
                            <input type="radio" name="gender" value="Female"/>Female
                        </td>
                    </tr>
                    <tr>
                        <td>
                        </td>
                        <td>
                            <input type="radio" name="gender" value="Other"/>Other
                        </td>
                        <td>
                            <input type="radio" name="gender" value="noReply"/>Prefer not to answer
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Do you have normal or corrected-to-normal vision?
                        </td>
                        <td>
                            <input type="radio" name="vision" value="yes"/>Yes
                        </td>
                        <td>
                            <input type="radio" name="vision" value="no"/>No
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Do you have a known color vision deficiency (e.g. color-blindness)?
                        </td>
                        <td>
                            <input type="radio" name="cvd" value="yes"/>Yes
                        </td>
                        <td>
                            <input type="radio" name="cvd" value="no"/>No
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Approximately how many hours do you spend on a computer each day:
                        </td>
                        <td>
                            <input id="compTime" name="compTime" type="number" value="0" min="0" max="24" class="numBox"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            What is the highest level of education you have received?
                        </td>
                        <td colspan="2">
                            <select id="education" name="education">
                                <option value="highSchool">High School</option>
                                <option value="someCollege">Some College</option>
                                <option value="collegeGraduate">Graduated College</option>
                                <option value="graduateStudies">Graduate Studies</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            What is your level of experience with data analysis?
                        </td>
                        <td colspan="2">
                            <select id="data_analysis_experience" name="data_analysis_experience">
                                <option value="none">1 (None)</option>
                                <option value="low">2</option>
                                <option value="medium">3</option>
                                <option value="high">4</option>
                                <option value="expert">5 (Expert)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            What is your level of experience with machine learning?
                        </td>
                        <td colspan="2">
                            <select id="ml_experience" name="ml_experience">
                                <option value="none">1 (None)</option>
                                <option value="low">2</option>
                                <option value="medium">3</option>
                                <option value="high">4</option>
                                <option value="expert">5 (Expert)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            What type of display did you complete this study on?
                        </td>
                        <td colspan="2">
                            <select id="display" name="display">
                                <option value="laptop">Laptop Computer</option>
                                <option value="desktop">Desktop Computer</option>
                                <option value="netbook">Netbook</option>
                                <option value="tablet">Tablet</option>
                                <option value="phone">Mobile Phone</option>
                                <option value="other">Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            How large is your monitor/display in inches (enter -1 for unknown)?
                        </td>
                        <td colspan="2">
                            <input id="size" name="size" type="number" value="0" min="-1" max="100" class="numBox"/>
                        </td>
                    </tr>
                </table>
            </form>
            <p>Any additional comments:</p>
            <textarea id="comments" name="comments" cols="100" form="demoForm"></textarea>
            <div id="submit">
                <button id="submitButton" class="lowerLeftButton" onclick="submitData();">Submit</button>
            </div>
        </div>
        </div>
    </body>
</html>
