function submitData() {
    if (parseInt($("#age").val() === 0) || $("#occupation").val() === "" ||
        $("input:radio[name=gender]:checked").val() === undefined ||
        $("input:radio[name=vision]:checked").val() === undefined ||
        $("input:radio[name=cvd]:checked").val() === undefined ||
        parseInt($("#size").val() === 0)) {
        alert("Please ensure all fields have been filled out and resubmit.");
    } else {
        // send to database
        // var query = window.location.search;
        // if (query.substring(0, 1) == '?')
        //     query = query.substring(1);
        // var id = parseInt(query);
        // $("#userId").val(id);

        // Set userId
        getUserId(function(callBack) {
            if (callBack == "success") {
                $("#userId").val(userId);
                $("#demoForm").submit();
            }
        });
    }
}

function writeResponses() {
    /// Write the study end time
    $.ajax({
        type: 'POST',
        url: 'static/php/submitDemographics.php',
        async: false,
        data: $('#demoForm').serialize(),
        complete: function(e) {
            console.log(e);
            return true;
        }
    });
    return true;
}
