// Stimulus set variables
var tot_num_correct_trials = (IN_DEVELOPMENT) ? 1 : 4;
var correct_trials = {"A" : 0, "B" : 0};
var correct_dog_classes;
var dog_tutorial_filepaths;
var tutorial_running = true;

// Active stimulus variables
var trial_i = 0;
var color = [];
var size = 0;
var userId = 0;
var query="";
var user_response;
var activeColor;
var adjustedColor;
var respInt;
var positions = [];
var adjustedSize = [20, 200];
var gap;

var breed_key = {};
var example_image_paths = [];

function setBreedKeys(breed_info) {
    var breeds = breed_info.split("\n");
    var cleaned_breeds = [];
    for (var i=0; i < breeds.length; i++) {
        var breed_str = breeds[i];
        if (breed_str === "") { continue; }
        var breed_split = breed_str.split(":");
        var breed_class = breed_split[0].trim();
        var breed_name = breed_split[1].trim();
        breed_key[breed_class] = breed_name;
    }
}

function setTutorialImagesList(tutorial_images_list) {
    dog_tutorial_filepaths = [];
    for (var i=0; i < tutorial_images_list.length; i++) {
        var tutorial_image = tutorial_images_list[i].split(APP_DIRECTORY)[1].replace("//", "/");
        dog_tutorial_filepaths.push(tutorial_image);
    }

    // Shuffle array
    dog_tutorial_filepaths = shuffle_images(dog_tutorial_filepaths);
}

function setExampleImagesList(example_images_list) {
    for (var img_i=0; img_i < example_images_list.length; img_i++) {
        var example_image_path = example_images_list[img_i].split(APP_DIRECTORY)[1];
        example_image_paths.push(example_image_path);
    }
    setExampleImages();
}

function init_PHP(main_callBack) {
    get_PHP_info(function(config_callBack) {

        if (config_callBack["success"] === true) {
            setBreedKeys(config_callBack.data.class_breed_info);
            setExampleImagesList(config_callBack.data.example_images);
            setTutorialImagesList(config_callBack.data.tutorial_images);
            main_callBack(true);
        }
        else {
            main_callBack(config_callBack);
        }
    });
}

function get_PHP_info(callBack) {
    var send_data = {
        "fxn" : "load_information"
    }
    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/
    $.post("static/php/tutorial_helper.php", {data : dataString},
    function(receive_data) {
        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = receive_data;
        }
        callBack(data);
    });
}

$(function() {
    init_PHP(function(main_callBack) {
        if (main_callBack === true) {
            main();
        }
        else {
            console.log(main_callBack);
            console.log("PHP Fail!");
        }
    });
});

function main() {
    // Parse the query variables
    t = new Date();
    query = window.location.search;
    if (query.substring(0, 1) == '?') {
        query = query.substring(1);
    }

    userId = parseInt(query.substring(0, query.indexOf("&")));

    // Establish the display layout
    var d = query.substring(query.indexOf("-d=") + 3);
    $("#stimulus").height(400);
    trial_i = 0;

    window.onbeforeunload = function() {
        // return "";
    }

    window.addEventListener("keyup", function (event) {
        if (event.defaultPrevented) {
            return; // Do nothing if the event was already processed
        }

        switch (event.key) {
        case "f":
        case "F":
            user_response = "A";
            break;
        case "j":
        case "J":
            user_response = "B";
            break;
        default:
            return; // Quit when this doesn't handle the key event.
        }

        // TODO: Do I need to send a response to adapt?
        // TODO: Turn off delay here?
        adapt();

        // Cancel the default action to avoid it being handled twice
        event.preventDefault();
    }, true);

    // Select Photo
    nextImage();
    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select("#tutorial_image")
            .transition().duration(500)
            .style("opacity", 1.0);
    }, 1000);
}



function shuffle_images(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}




function setExampleImages() {
    var img_IDs = ["#dog_A_example_img", "#dog_B_example_img"];
    for (var img_i=0; img_i < example_image_paths.length; img_i++) {
        var example_img = example_image_paths[img_i];
        var img_id = img_IDs[img_i];
        d3.select(img_id).attr("src", example_img);
    }
}


function nextImage() {
    // remove previous image
    d3.select("#tutorial_image").remove();

    // Select next image from list
    var img = dog_tutorial_filepaths[trial_i];

    // Append new image
    d3.select("#tutorial_test_image_div").append("img")
        .attr("id", "tutorial_image")
        .attr("src", img)
        .style("opacity", 0.0);
}

function getCorrectAnswer() {
    var current_dog_class = dog_tutorial_filepaths[trial_i];
    var split_string = current_dog_class.split("/")[4];
    var correct_answer = split_string.split("_")[1];
    return correct_answer;
}

function logResponse() {
    if (adaptationScreenOn) {
        console.log("Adaption screen on. Wait to click.");
        return;
    }

    // Get the correct answer
    var correct_answer = getCorrectAnswer();

    clearInterval(respInt);

    var error_msg = "Incorrect. Please press the 'F' key if the image appears to be dog breed A and the 'J' key if the image appears to not be dog breed A.";

    if ((correct_trials.A >= tot_num_correct_trials) && (correct_trials.B >= tot_num_correct_trials)) {
        if (user_response == correct_answer) {
            tutorial_running = false;
            d3.select('body').transition().duration(250).style("opacity", 0.4);
            setTimeout(function() {
                alert("Correct. Press 'OK' to exit this window and begin the study.");
                postResponseValues();
                return;
            }, 250);
            return;
        }
        else if (!tutorial_running) {
            return;
        }
        else {
            alert(error_msg);
            correct_trials[correct_answer]--;
            correct_trials[correct_answer] = Math.max(0, correct_trials[correct_answer]);
            return;
        }
    }
    else {
        if (user_response == correct_answer) {
            alert("Correct.");
            correct_trials[correct_answer]++;
        }
        else {
            alert(error_msg);
            correct_trials[correct_answer]--;
            correct_trials[correct_answer] = Math.max(0, correct_trials[correct_answer]);
            return;
        }
    }

    trial_i++;
    adaptationScreen("#tutorial_image");
};



var checked = function($btn) {
    return $btn.val();
};

var postResponseValues = function() {
    window.location = "study.php?" + query;
};
