// Session variables -- not all of these are implemented
var IN_DEVELOPMENT = false;
var APP_DIRECTORY = "oracle_query/S1/AI_A1/";
var userId = "";
var adaptationScreenOn = false;

function adaptationScreen(img_id) {
    d3.select(img_id)
        .transition().duration(500)
        .style("opacity", 0.0);

    setTimeout(function() {
        nextImage();
    }, 700);

    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select(img_id)
            .transition().duration(200)
            .style("opacity", 1.0);
    }, 750);
}

function getUserId(callBack) {
    $.ajax({
        url: 'static/php/utils.php',
        data: {action: 'fetchUserId'},
        type: 'post',
        success: function(response) {
            userId = parseInt($.parseJSON(response));
            callBack("success");
        }
    });
}
