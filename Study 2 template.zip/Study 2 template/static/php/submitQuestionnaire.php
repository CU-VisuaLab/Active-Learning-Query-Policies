<?php
error_reporting(E_ALL ^ E_DEPRECATED);
print_r($_POST);

$query = "INSERT INTO mli_study2.questionnaire_data VALUES " . $_POST['responses'] . ";";

try {
    $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");
    if (!$db) {
        throw new Exception('Error connecting to mysql');
    }

    $result = mysqli_query($db, $query);
    if (!$result) {
        die('Trouble:' . mysqli_error($db) . $query . '<br \>');
    }

    mysqli_close($db);
    echo "Success";
}
catch (Exception $e) {
    die('Trouble:' . mysqli_error($db) . '<br \>');
    echo 'Troubles:<br \>';
    echo $e . '<br \>';
}
?>
