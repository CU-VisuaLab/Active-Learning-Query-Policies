$(function() {

    $(".progress-bar").animate({
        width: "100%"
    }, 5000);

    setTimeout(function() {
        $(".progress-bar").removeClass("progress-bar-info active").addClass("progress-bar-success");
        d3.select(".progress-bar").html("Training Complete");
    }, 5500);

    setTimeout(function() {
        var input_button = d3.select("#transition_button_div").append("input")
            .attr("type", "button")
            .attr("value", "Next")
            .on("click", function() {
                window.location = "phase_2.php";
            })
            .style("opacity", 0.0);

        input_button.transition().duration(750).style("opacity", 1.0);
        d3.select("#training_text").transition().duration(750).style("opacity", 1.0);

    }, 6000);

});
