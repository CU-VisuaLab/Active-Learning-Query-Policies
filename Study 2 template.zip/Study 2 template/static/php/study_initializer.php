<?php

    function load_information($DATASET_ID) {

        $parent_dir = dirname(__DIR__);

        $upOne = realpath($parent_dir . '/..');
        $upOne = realpath($upOne . '/..');
        $upOne = realpath($upOne . '/..');
        $upOne = realpath($upOne . '/..');

        $study_dir = $upOne . '/imgs/' . $DATASET_ID . '/study/';
        $tutorial_dir = $upOne . '/imgs/' . $DATASET_ID . '/tutorial/';

        // Get dog breed keys
        $config_filepath = $tutorial_dir . "/dog_breed_key.txt";
        $file_contents = file_get_contents($config_filepath, true);


        // Get tutorial images
        $study_images_dir = $study_dir . "/dogs/";
        $study_images = array();
        foreach (glob($study_images_dir . "*.png") as $filename) {
            array_push($study_images, $filename);
        }

        // Get attention checks
        $attention_check_images_dir = $study_dir . "/attention_check/";
        $attention_check_images = array();
        foreach (glob($attention_check_images_dir . "*.png") as $filename) {
            array_push($attention_check_images, $filename);
        }

        $return_data = array(
            "class_breed_info" => $file_contents,
            "attention_checks" => $attention_check_images,
            "study_images" => $study_images
        );

        echo json_encode($return_data);
    }

    $msg = json_decode($_POST["data"], true);
    if ($msg["fxn"] == "load_information") {
        load_information($msg["dataset"]);
    }
    else {
        echo json_encode("fail");
    }
    // echo json_encode($msg);

    // if ($msg)
    // get_example_images();
?>
