<?php $css_sheet_name = "study_style"; ?>
<?php $js_filename = "phase_2"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
<body>

    <div id="test_panel">
        <div id="Instructions">

            <p>
                In this phase, you will evaluate the system you just trained. <br>
                As in the previous phase, you will be presented with an image, along with the system's classification (Dog Breed A or <b>not</b> Dog Breed A) of that image. <br>
                Your job is to evaluate the system's classification as <b>correct</b> or <b>incorrect</b>.<br>
                For each evaluation you must fill out the 4 questions below the image, then press next to see the next image.
            </p>
            <label id="progress"></label> <br /> <label id="loading"></label>
        </div>
        <div id="panel">
            <div id="stimuli">
                <div id="study_image_div">
                    <div id="image_classification_div">
                        <p id="study_image_classification"></p>
                    </div>
                </div>
            </div>
        </div>
        <div id="dpi"></div>
    </div>

    <form id="responseForm" method="post">
        <input type="hidden" id="responses" name="responses"></input>
    </form>

    <div id=wrap_div>
        <div class="wrap" id="confirm_confidence">
            <form action="" onSubmit="return finishLoggingResponse()">
                <label class="statement statement_phase_2">How much do you agree or disagree with the system's classification?</label>
                <ul class='likert likert_phase_2', id="agreement_likert">
                    <li>
                        <input type="radio" name="agreement_likert" value="strong_disagree">
                        <label>Strongly Disagree</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="moderate_disagree">
                        <label>Moderately Disagree</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="weak_disagreet">
                        <label>Weakly Disagree</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="neutral">
                        <label>Neutral</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="weak_agree">
                        <label>Weakly Agree</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="moderate_agree">
                        <label>Moderately Agree</label>
                    </li>
                    <li>
                        <input type="radio" name="agreement_likert" value="strong_agree">
                        <label>Strongly Agree</label>
                    </li>
                </ul>
                <label class="statement statement_phase_2">How confident are you in your decision to keep or change the system's classification?</label>
                <ul class='likert likert_phase_2', id="user_confidence_likert">
                    <li>
                        <input type="radio" name="user_confidence_likert" value="strong_unconfident">
                        <label>Strongly Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="moderate_unconfident">
                        <label>Moderately Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="weak_unconfident">
                        <label>Weakly Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="neutral">
                        <label>Neutral</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="weak_confident">
                        <label>Weakly Confident</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="moderate_confident">
                        <label>Moderately Confident</label>
                    </li>
                    <li>
                        <input type="radio" name="user_confidence_likert" value="strong_confident">
                        <label>Strongly Confident</label>
                    </li>
                </ul>
                <label class="statement statement_phase_2">How confident are you in the <b>system's</b> classification?</label>
                <ul class='likert likert_phase_2', id="system_confidence_likert">
                    <li>
                        <input type="radio" name="system_confidence_likert" value="strong_unconfident">
                        <label>Strongly Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="moderate_unconfident">
                        <label>Moderately Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="weak_unconfident">
                        <label>Weakly Unconfident</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="neutral">
                        <label>Neutral</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="weak_confident">
                        <label>Weakly Confident</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="moderate_confident">
                        <label>Moderately Confident</label>
                    </li>
                    <li>
                        <input type="radio" name="system_confidence_likert" value="strong_confident">
                        <label>Strongly Confident</label>
                    </li>
                </ul>
                <label class="statement statement_phase_2">Is the <b>system's</b> classification correct or incorrect?</label>
                <ul class='likert likert_phase_2 likert_phase_3', id="user_answer">
                    <li>
                        <input type="radio" name="user_answer" value="keep">
                        <label>Correct</label>
                    </li>
                    <li>
                        <input type="radio" name="user_answer" value="change">
                        <label>Incorrect</label>
                    </li>
                </ul>
            </form>
            <div id="next_button_div"> </div>
        </div>
    </div>
</body>
</html>
