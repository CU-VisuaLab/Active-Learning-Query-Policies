<?php $css_sheet_name = "tutorial_style"; ?>
<?php $js_filename = "tutorial"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
<?php require("static/php/utils.php"); ?>

<!-- Store data -->
<?php logUserToDB('"' . $_SERVER['QUERY_STRING'] . '"');?>


<!-- MAIN BODY -->
<body>
    <div id="panel" class="centralPanel">
        <div id="example_image_container">
            <div class="row">
                <div id="dog_breed_A_example">
                    <img src="" id="dog_A_example_img">
                    <p> Dog Breed <b>A</b> </p>
                </div>
                <div id="dog_breed_B_example">
                    <img src="" id="dog_B_example_img">
                    <p> Dog Breed <b>B</b> </p>
                </div>
            </div>
        </div>
        <p>
            The following questions will teach you how to use this study.
            For the next series of images, press the "F" key if the image appears to be dog breed
            A and the "J" key if the image appears to <b> not </b> be dog breed A. Note that the images in the actual
            study will be lower quality and more difficult to discern. <br><br>
            <b> Important </b>: In the section that follows this tutorial, you will be required to recall the distintion between dog breeds A and B; be sure to memorize which dog is Dog Breed A and which is Dog Breed B as best you can.
        </p>
        <div id="tutorial_test_image_div">
            <p> Is this the dog in this image Dog Breed A (<b>key 'F'</b>), or not (<b>key 'J'</b>)? </p>
            <!-- Tutorial Image will be placed here by d3 -->
        </div>
        <table height="500px" style="top:10px">
            <tr height="500px">
                <td style="padding-left: 175px">
                    <div id="stimulus" width="700px" height="400px"></div>
                </td>
            </tr>
            <tr>
                <td width="25%" align="center">
                </td>
            </tr>
            <tr>
                <td>
                    <div id="submit">
                        <button id="submitButton" class="lowerLeftButton" style="visibility: hidden">Submit</button>
                    </div>
                </td>
            </tr>
        </table>
    </div>
    <div id="dpi"></div>

</body>
</html>
