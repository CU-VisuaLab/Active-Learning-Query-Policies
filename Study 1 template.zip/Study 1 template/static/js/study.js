var sessionTime = 0;
var dpi = 0;
var inchesToDisplay = 30;
var startTime = 0;
var endTime = 0;
var trialStartTime = 0;
var resp = "none";
var numCircles = 1;
var iters = 0;
var cvd = "n";
var trial_i = 0;
var attention_check_i = 0;
var current_img;
var study_running = true;
var dog_breed_key;
var skip_image = false;

var TRIALS_PER_PARTICIPANT;

// Display parameters
var colorType = null;
var baseStep = 0.5;
var background = "white";

var LARGEST_SIZE = visualAngleToPixels(6.0, 30, 96);

// This is something that is important

// Layout parameters
var positions = [];
var proximity = 0;
var respInt;
var whiteInt;
var layoutType = "grid";


function add_attention_checks(dogs, attention) {
    var insert_intervals = [20, 40, 60, 80];
    var insert_i = 0;
    var combined_list = [];
    for (var img_i=0; img_i < dogs.length; img_i++) {
        if (img_i === insert_intervals[insert_i]) {
            combined_list.push(attention[insert_i]);
            insert_i++;
        }
        combined_list.push(dogs[img_i]);
    }
    console.log(combined_list);
    console.log(combined_list.length);
    TRIALS_PER_PARTICIPANT = IN_DEVELOPMENT ? 10 : combined_list.length;
    return combined_list;
}

function setStudyImagesList(study_images_list, attention_check_list) {
    dog_study_filepaths = [];
    for (var i=0; i < study_images_list.length; i++) {
        var study_image = study_images_list[i].split(APP_DIRECTORY)[1].replace("//", "/");
        dog_study_filepaths.push(study_image);
    }

    // Sort attention check_list
    attention_check_filepaths = [];
    for (var i=0; i < attention_check_list.length; i++) {
        var attention_check_image = attention_check_list[i].split(APP_DIRECTORY)[1].replace("//", "/");
        attention_check_filepaths.push(attention_check_image);
    }

    // Shuffle array
    dog_study_filepaths = shuffle_images(dog_study_filepaths);

    // Add attention checks
    dog_study_filepaths = add_attention_checks(dog_study_filepaths, attention_check_filepaths);
}

function get_PHP_info(callBack) {
    var send_data = {
        "fxn" : "load_information"
    }
    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/
    $.post("static/php/study_initializer.php", {data : dataString},
    function(receive_data) {
        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = false;
        }
        callBack(data);
    });
}

function init_PHP(main_callBack) {
    get_PHP_info(function(config_callBack) {
        if (config_callBack["success"] === true) {
            dog_breed_key = config_callBack.data.class_breed_info;
            setStudyImagesList(config_callBack.data.study_images, config_callBack.data.attention_checks);
            main_callBack(true);
        }
        else {
            main_callBack(false);
        }
    });
}


$(function() {
    init_PHP(function(main_callBack) {
        if (main_callBack === true) {
            getUserId(function(callBack) {
                if (callBack == "success") {
                    initializeStudy();
                }
            });
        }
        else {
            console.log("PHP Fail!");
        }
    });
});


//--------------------------------------------------------------- Utility Functions ---------------------------------------------------------->



function initializeStudy() {
    if (IN_DEVELOPMENT) {
        console.log("User id: " + userId);
    }

    // Extract the demographic form parameters
    $("#instructions_panel").remove();
    document.getElementById("test_panel").style.visibility = 'visible';

    // Fetch the DPI and id
    startSession();
    dpi = $("#dpi").height();

    // Fetch the configs
    colorType = COLORTYPE['Lab'];
    proximity = visualAngleToPixels(5, inchesToDisplay, dpi);

    // Leftovers from social media study
    baseStep = 0.33;
    background = "white";
    $("document").css("background-color", background);

    // Parse command line argument (important)
    var urlArgs = window.location.search;


    // Set the panel widget
    var nc = 1;
    var nr = 1;
    var panelW = (layoutType == "grid") ? (2 * proximity + 2 * GRID_PAD + LARGEST_SIZE) * nc :
        2 * (proximity + 2 * LARGEST_SIZE);

    var panelH = (proximity + LARGEST_SIZE);
    $("#stimuli").width(panelW);
    $("#stimuli").height(panelH);
    $("#stimuli").css("padding-top", "100px");
    $("#panel").width(panelW);
    $("#panel").height(panelH + 100);
    $("#panel").width($("#panel").width());

    // Instantiate the keyboard input
    window.addEventListener("keyup", function (event) {
        if (event.defaultPrevented) {
            return; // Do nothing if the event was already processed
        }

        switch (event.key) {
        case "f":
        case "F":
            user_response = "A";
            adapt(true);
            break;
        case "j":
        case "J":
            user_response = "B";
            adapt(true);
            break;
        default:
            return; // Quit when this doesn't handle the key event.
        }

        // Cancel the default action to avoid it being handled twice
        event.preventDefault();
    }, true);

    // Instantiate the study
    trialStartTime = new Date();
    runStudy();
}



function shuffle_images(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

function updateProgress() {
    $("#progress").html("Completed " + trial_i + " / " + TRIALS_PER_PARTICIPANT + " trials");
}

function nextImage() {
    startTime = new Date();

    // remove previous image
    d3.select("#study_image").remove();

    // Select next image from list
    current_img = dog_study_filepaths[trial_i];

    console.log(current_img);

    // Append new image
    d3.select("#study_image_div").append("img")
        .attr("id", "study_image")
        .attr("src", current_img)
        .style("opacity", 0.0);

    updateProgress();
}

function startSession() {
    var date = new Date();
    sessionTime = (date.getMonth() + 1) + "_" + date.getDate() + "_" + date.getHours() + "_" + date.getMinutes() + "_" + date.getSeconds();
    return true;
}

function getCorrectAnswer() {
    var current_dog_class = dog_study_filepaths[trial_i];
    var split_string = current_dog_class.split("/")[4];
    var correct_answer = split_string.split("_")[1];
    return correct_answer;
}

function logResponse() {
    var userCorrect;

    if (adaptationScreenOn) {
        console.log("Adaption screen on. Wait to click.");
        return;
    }

    if (!study_running) {
        return;
    }

    // Get the correct answer
    var correct_answer = getCorrectAnswer();


    // Clear interval
    clearInterval(respInt);
    // TODO: Log whether or not answer was correct!
    if (user_response == correct_answer) {
        // console.log("CORRECT");
        userCorrect = true;
    }
    else {
        // console.log("INCORRECT");
        userCorrect = false;
    }

    // Write data
    // TODO: Fix this in writeData.js!
    writeData(startTime, endTime, userCorrect);

    trial_i++;

    if (trial_i === TRIALS_PER_PARTICIPANT) {
        d3.select('body').transition().duration(500).style("opacity", 0.4);
        study_running = false;
        updateProgress();
        setTimeout(function() {
            alert("DONE!");
            pushStudyResultsToDatabase();
            return;
        }, 500);
    }
    else if (!study_running) {
        return;
    }
    else {
        // Generate the next image
        adaptationScreen("#study_image");
    }
}
function runStudy() {

    // Reset the response
    clearInterval(respInt);

    // Select Photo
    nextImage();
    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select("#study_image")
            .transition().duration(1000)
            .style("opacity", 1.0);
    }, 800);
}
