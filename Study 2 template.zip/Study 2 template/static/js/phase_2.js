var sessionTime = 0;
var dpi = 0;
var inchesToDisplay = 30;
var startTime = 0;
var endTime = 0;
var trialStartTime = 0;
var resp = "none";
var numCircles = 1;
var iters = 0;
var cvd = "n";
var trial_i = 0;
var attention_check_i = 0;
var current_img;
var study_running = true;
var dog_breed_key;
var dog_breed_key_raw;
var dog_breed_key_inverse;
var confidence_scores = {};
var radio_ids = ["agreement_likert", "user_confidence_likert", "system_confidence_likert", "user_answer"];
var majority_label;

// Display parameters
var colorType = null;
var baseStep = 0.5;
var background = "white";

var LARGEST_SIZE = visualAngleToPixels(6.0, 30, 96);

// This is something that is important

// Layout parameters
var positions = [];
var proximity = 0;
var respInt;
var whiteInt;
var layoutType = "grid";

jQuery.browser = {};

function add_attention_checks(dogs, attention) {
    var insert_intervals = [20, 40, 60, 80];
    var insert_i = 0;
    var combined_list = [];
    for (var img_i=0; img_i < dogs.length; img_i++) {
        if (img_i === insert_intervals[insert_i]) {
            combined_list.push(attention[insert_i]);
            insert_i++;
        }
        combined_list.push(dogs[img_i]);
    }

    return combined_list;
}



function get_PHP_info(callBack) {
    var send_data = {
        "fxn" : "load_information",
        "dataset"   : APP_DIRECTORY
    }
    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/
    $.post("static/php/study_initializer.php", {data : dataString},
    function(receive_data) {
        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = false;
        }
        callBack(data);
    });
}

function init_PHP(main_callBack) {
    get_PHP_info(function(config_callBack) {
        if (config_callBack["success"]) {
            dog_breed_key_raw = config_callBack.data.class_breed_info;
            dog_breed_key_raw = dog_breed_key_raw.split("\n");
            dog_breed_key = {};
            for (var i=0; i<2; i++) {
                var dog = dog_breed_key_raw[i].split(" : ");
                var key = dog[0];
                var val = dog[1];
                dog_breed_key[key] = val;
            }
            console.log(dog_breed_key);
            dog_breed_key_inverse = {}
            for (var dog_key in dog_breed_key) {
                var dog_val = dog_breed_key[dog_key];
                dog_breed_key_inverse[dog_val] = dog_key;
            }
            console.log(dog_breed_key_inverse);
            main_callBack(true);
        }
        else {
            main_callBack(false);
        }
    });
}


$(function() {
    var CURRENT_PHASE = "test";
    init_PHP(function(main_callBack) {
        if (main_callBack) {
            getUserId(function(callBack) {
                if (callBack === "success") {
                    initializeData(CURRENT_PHASE, function(dataCallback) {
                        if (dataCallback === "success") {
                            initializeStudy();
                        }
                    });
                }
            });
        }
        else {
            console.log("PHP Fail!");
        }
    });
});


//--------------------------------------------------------------- Utility Functions ---------------------------------------------------------->



function initializeStudy() {
    if (IN_DEVELOPMENT) {
        console.log("User id: " + userId);
    }

    // Extract the demographic form parameters
    $("#instructions_panel").remove();
    document.getElementById("test_panel").style.visibility = 'visible';

    // Fetch the DPI and id
    startSession();
    dpi = $("#dpi").height();

    // Fetch the configs
    colorType = COLORTYPE['Lab'];
    proximity = visualAngleToPixels(5, inchesToDisplay, dpi);

    // Leftovers from social media study
    baseStep = 0.33;
    background = "white";
    $("document").css("background-color", background);

    // Parse command line argument (important)
    var urlArgs = window.location.search;


    // Set the panel widget
    var nc = 1;
    var nr = 1;
    var panelW = (layoutType == "grid") ? (2 * proximity + 2 * GRID_PAD + LARGEST_SIZE) * nc :
        2 * (proximity + 2 * LARGEST_SIZE);

    var panelH = (proximity + LARGEST_SIZE);
    $("#stimuli").width(panelW);
    $("#stimuli").height(panelH);
    // $("#stimuli").css("padding-top", "100px");
    // $("#panel").width(panelW);
    $("#panel").width("100%");
    $("#panel").height(panelH);
    $("#panel").width($("#panel").width());

    var instructions_height = $("#Instructions").height();
    var panel_height = $("#panel").height();

    // $("#confirm_confidence").css("padding-top", "100px");
    $("#wrap_div").css("position", "absolute");
    $("#wrap_div").css("top", instructions_height+panel_height+10);

    // Instantiate the keyboard input
    // window.addEventListener("keyup", function (event) {
    //     if (event.defaultPrevented) {
    //         return; // Do nothing if the event was already processed
    //     }
    //
    //     switch (event.key) {
    //     case "f":
    //     case "F":
    //         user_response = "Keep";
    //         adapt(true);
    //         break;
    //     case "j":
    //     case "J":
    //         user_response = "Change";
    //         adapt(true);
    //         break;
    //     default:
    //         return; // Quit when this doesn't handle the key event.
    //     }
    //
    //     // Cancel the default action to avoid it being handled twice
    //     event.preventDefault();
    // }, true);
    d3.select("#next_button_div").append("input")
        .attr("type", "button")
        .attr("value", "Next")
        .on("click", function() {
            adapt(true);
        });

    // Instantiate the study
    trialStartTime = new Date();
    runStudy();
}

function shuffle_images(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    return array;
}

function updateProgress() {
    $("#progress").html("Completed " + trial_i + " / " + TRIALS_PER_PARTICIPANT + " trials");
}

function nextImage() {
    startTime = new Date();

    // remove previous image and classification
    d3.select("#study_image").remove();

    for (var i=0; i < radio_ids.length; i++) {
        d3.select("#"+radio_ids[i]).transition().style("background-color", "#fff");
    }


    // Select next image from list
    var current_img_i = study_1_data[trial_i];

    // Get current image location
    current_img = current_img_i['path'];

    // Confidence
    var current_img_confidence = current_img_i["img_confidence"];

    // Correctness
    var current_img_correctness = current_img_i["img_correctness"];

    // Majority Label
    majority_label = current_img_i["majority_label"];

    // Image ID
    var current_img_id = extract_image_name(current_img_i["img_name"]);

    d3.select("#study_image_div").style("opacity", 0.0);

    // Append new image
    d3.select("#study_image_div").append("img")
        .attr("id", "study_image")
        .attr("src", current_img);

    // Append text
    var label = (dog_breed_key_inverse[majority_label] === "dog_A") ? "Dog Breed A" : "Not Dog Breed A";
    d3.select("#study_image_classification").html("System Classification<br>"+label);

    updateProgress();
}

function startSession() {
    var date = new Date();
    sessionTime = (date.getMonth() + 1) + "_" + date.getDate() + "_" + date.getHours() + "_" + date.getMinutes() + "_" + date.getSeconds();
    return true;
};

function finishLoggingResponse(confidence_scores) {

    // Write data
    // TODO: Fix this in writeData.js!
    writeData_phase_2(startTime, endTime, majority_label, confidence_scores);

    trial_i++;

    if (trial_i === TRIALS_PER_PARTICIPANT) {
        d3.select('body').transition().duration(500).style("opacity", 0.4);
        study_running = false;
        updateProgress();
        setTimeout(function() {
            query = window.location.search;
            if (query.substring(0, 1) == '?') {
                query = query.substring(1);
            }
            pushStudyResultsToDatabase("phase_2");
            alert("DONE!");
            return;
        }, 500);
    }
    else if (!study_running) {
        return;
    }
    else {
        // Generate the next image
        adaptationScreen("#study_image_div");
    }
}


function check_confidence_rated() {

    var missing_radios = [];
    var checked_radios = [];
    var num_checked = 0;
    confidence_scores = {};
    for (var i=0; i < radio_ids.length; i++) {
        var radio_id = radio_ids[i];
        var radios = document.getElementsByName(radio_id);
        var at_least_one_checked = false;
        for (var j = 0; j < radios.length; j++)
        {
            if (radios[j].checked)
            {
                at_least_one_checked = true;
                confidence_scores[radio_id] = j+1;
                num_checked++;
            }
        }

        if (!at_least_one_checked) {
            missing_radios.push(radio_id);
        }
        else {
            checked_radios.push(radio_id);
        }
    }

    return num_checked === radio_ids.length ? [true, checked_radios, missing_radios] : [false, checked_radios, missing_radios];
}

function logResponse() {

    if (adaptationScreenOn) {
        console.log("Adaption screen on. Wait to click.");
        return;
    }

    if (!study_running) {
        return;
    }

    var [all_checked, checked_radios, missing_radios] = check_confidence_rated();

    for (var i=0; i < checked_radios.length; i++) {
        var checked_radio = checked_radios[i];
        d3.select("#"+checked_radio).transition().style("background-color", "#ccffcc");
    }

    if (!all_checked) {
        alert("Finish rating your confidence in the system's classification before continuing.");
        for (var i=0; i < missing_radios.length; i++) {
            var missing_radio = missing_radios[i];
            d3.select("#"+missing_radio).transition().style("background-color", "#ffcccc");
        }
        return;
    }



    // Clear interval
    clearInterval(respInt);

    rating_confidence = true;

    // Clear all radios
    setTimeout(function() {
        for (var i=0; i < radio_ids.length; i++) {
            var radios = document.getElementsByName(radio_ids[i]);
            for (var j=0; j < radios.length; j++)
            {
                radios[j].checked = false;
            }
        }
    }, 750);

    finishLoggingResponse(confidence_scores);
};


function runStudy() {

    jQuery.browser.msie = false;
    jQuery.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
        jQuery.browser.msie = true;
        jQuery.browser.version = RegExp.$1;
    }

    // Reset the response
    clearInterval(respInt);

    // Select Photo
    nextImage();
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select("#confirm_confidence").transition().duration(1000).style("opacity", 1.0);
        d3.select("#study_image_div")
            .transition().duration(1000)
            .style("opacity", 1.0);
    }, 800);
};
