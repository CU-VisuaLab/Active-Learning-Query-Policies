<?php
ini_set('display_errors',1);
error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL ^ E_DEPRECATED);
function hasTaken(){
		try{
		$db = mysqli_connect("studies.cu-visualab.org","visualab","database1");
		if(!$db){
			throw new Exception('Error connecting to mysql');
		}
		$result = mysqli_query($db, 'SELECT count(*) as num from mli_test.user_data where ip="'.$_SERVER['REMOTE_ADDR'].'";');
		if(!$result){
			die('Trouble:'.mysqli_error($db).'<br \>');
		}
		$row = mysqli_fetch_assoc($result);
		if(!$row || $row['num']==0){
			echo "false";
		}
		else{
			echo "true";
		}
		mysqli_close($db);
	}
	catch(Exception $e){
		echo "true";
	}
}
?>
