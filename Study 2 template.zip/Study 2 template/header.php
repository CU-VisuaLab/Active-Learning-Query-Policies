<?php
    if (!isset($page_title)) {
        $page_title = "Evaluating Active Learning Oracle Querying Policies";
    }

    if (!isset($css_sheet_name)) {
        $css_sheet_name = "style";
    }

    if (!isset($js_filename)) {
        $js_filename = "javascript";
    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <script type="text/javascript" src="static/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="condition_params.js"></script>

    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' integrity='sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u' crossorigin='anonymous'>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css' integrity='sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp' crossorigin='anonymous'>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' integrity='sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa' crossorigin='anonymous'></script>

    <title><?php echo $page_title ?></title>
    <?php if ($js_filename == "phase_1" || $js_filename == "phase_2" || $js_filename == "post_survey_questions") {
        echo " <link rel='stylesheet' type='text/css' href='static/css/main.css' />; ";
    }
    else if ($js_filename == "tutorial") {
        // echo " <link rel='stylesheet' type='text/css' href='static/css/tutorial_main.css' />; ";
    }
    ?>

    <link rel="stylesheet" type="text/css" href="static/css/<?php echo $css_sheet_name ?>.css"/>
    <link rel="stylesheet" type="text/css" href="static/css/jnd_test.css"/>

    <link href="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
    <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    <script type="text/javascript" src="static/js/d3.v4.min.js"></script>

    <!-- anything color (conversions, jitters, gamut, visual angle to pixels)-->
    <script type="text/javascript" src="static/js/colorconversion.js"></script>

    <!-- all the rendering and interaction-->
    <script type="text/javascript" src="static/js/stimuli.js"></script>

    <!-- process all data parameters, pipes out to PHP script via synchronous ajax-->
    <script type="text/javascript" src="static/js/initializer.js"></script>
    <script type="text/javascript" src="static/js/writeData.js"></script>
    <script type="text/javascript" src="static/js/<?php echo $js_filename; ?>.js"></script>


</head>
