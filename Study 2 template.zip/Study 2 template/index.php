<!-- See here for original: https://github.com/michael-iuzzolino/AI_trust/blob/8e259b54d09f8d8182da06f042b6abbe49d8c92a/2_experiment_primary/CrowdsourcingHarness-master/index.php -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="static/css/stylesheet.css" />
        <script type="text/javascript" src="static/js/jquery-1.4.2.js"></script>
        <script type="text/javascript" src="static/js/initializer.js"></script>
        <title>Evaluating Active Learning Oracle Querying Policies</title>
    </head>
    <body>
        <div class="largePanel">
            <script type="text/javascript">
                <?php require("static/php/index_utils.php"); ?>

                function gup( name )
                {
                    var regexS = "[\\?&]"+name+"=([^&#]*)";
                    var regex = new RegExp( regexS );
                    var tmpURL = window.location.href;
                    var results = regex.exec( tmpURL );
                    if( results == null ) {
                        return "";
                    }
                    else {
                        return results[1];
                    }
                }
                function decode(strToDecode)
                {
                    var encoded = strToDecode;
                    return unescape(encoded.replace(/\+/g,  " "));
                }
                function startExp(){
                    var userId = gup('assignmentId');
                    var turkId = gup('workerId');
                    window.open("tutorial.php?" + turkId + "&" + location.search.substring(1));
                }
                function checkTaken(){
                    // Disable the javascript error
                    document.getElementById('jscheck').innerHTML="<p></p>";
                    document.getElementById('readyBtn').disabled="";

                    // Check if user has taken
                    if( <?php hasTaken(); ?> ){
                        document.getElementById('readyBtn').disabled="disabled";
                        document.getElementById('commentsform').innerHTML="<h3>Sorry, but our records indicate that someone with your IP has already taken this test.</h3>";
                    }

                    // Load remainder!
                    document.getElementById('assignmentId').value = gup('assignmentId');
                    document.getElementById('workerId').value = gup('workerId');

                    // Check if the worker is PREVIEWING the HIT or if they've ACCEPTED the HIT
                    if (gup('assignmentId') == "ASSIGNMENT_ID_NOT_AVAILABLE")
                    {
                        document.getElementById('readyBtn').value="PLEASE ACCEPT HIT BEFORE CONTINUING";
                        document.getElementById('readyBtn').disabled = "disabled";
                        document.getElementById('commentsform').innerHTML="<p>You cannot submit while previewing.</p>";
                        // If we're previewing, disable the button and give it a helpful message
                        document.getElementById('submitButton').disabled = "disabled";
                        document.getElementById('submitButton').value = "You must ACCEPT the HIT before you can submit the results.";
                    }
                    else {
                        var form = document.getElementById('mturk_form');
                        if (document.referrer && ( document.referrer.indexOf('workersandbox') != -1) ) {
                            form.action = "//workersandbox.mturk.com/mturk/externalSubmit";
                        }
                    }
                }
                if (window.attachEvent) {
                    window.attachEvent('onload', checkTaken);
                }
                else if (window.addEventListener) {
                    window.addEventListener('load', checkTaken, false);
                }
                else {
                    document.addEventListener('load', checkTaken, false);
                }
            </script>

            <h2 class="header">Evaluating Active Learning Oracle Querying Policies</h2>
            <h3>Description of Research</h3>
            <p>
                You are invited to participate in a research study about humans interact with automatic image classification systems.
                The purpose of the research is to determine how much confidence a human has in the classification decisions of an
                automation system after an initial phase of training wherein the human teaches the system the correct classification of a sequence of images.
                This study will include <b>native English speakers</b> from <b>18 to 65 years old</b>, who feel comfortable using an online interface to classify images as one breed of dog or another.
            </p>
            <p>
                To reiterate, you are eligible for this study if and only if:
            <ul class="label">
                <li>You <b>have not</b> already completed this study.</li>
                <li>You are a native English speaker.</li>
                <li>You are between 18 and 65 years of age.</li>
                <li>You have JavaScript enabled in your browser.</li>
            </ul>
            </p>
            <h3>What Will My Participation Involve?</h3>
            <p>
                If you decide to participate in this research then you will participate in two phases. In the first phase, you will be shown a series of images along with dog breed classifications.
                You will be asked to determine whether the classification is correct or incorrect, and your response will help the automation system learn the correct labeling.
                In the second phase, you will again be shown a series of images along with the automation systems's classifications.
                However, in this phase this time you will be evaluating the system by either choosing to keep or change the automation system's classification decision.
                You may or may not be provided with a visualization of the system's confidence in a given classification.
                Afterwards, we will collect some basic demographic data. Please be aware that your responses will be vetted. If responses appear to be spam, the HIT will not be accepted.
            </p>
            <!--TODO: Update this duration based on your pilot testing (and multiple mean pilot times by 2)-->
            <h3>How Long Will This Take?</h3>
            <p>We expect this study to take less than 10 minutes.</p>
            <h3>Contact Information</h3>
            <p>
                If you have additional questions, please contact <a href="mailto:michael.iuzzolino@colorado.edu">Michael Louis Iuzzolino</a>.
                If you are not satisfied with the response of the research team or have more questions,
                you should contact the University of Colorado IRB Office at (303) 735-3702.
            </p>
            <p>
                By clicking "Ready" you confirm that you meet the criteria for this study and are ready to proceed. This will open up the study in a new window.
            </p>
            <p class="label" style="color:#900; font-size: 18pt">
                Please accept HIT before clicking 'Ready.' Do not leave this page until the study is completed!<br/><br/>
                <input id="readyBtn" type="submit" value="Ready" disabled="disabled" onClick="startExp()" />
            </p>
            <div id="jscheck">
                <p class="label">Javascript error. Please check browser settings before accepting HIT.</p>
            </div>
            <p>
                If you are participating from Mechanical Turk, the submission information will appear here once you are done:
            </p>
            <p>
            <form id="mturk_form" method="POST" action="//www.mturk.com/mturk/externalSubmit">
                <input type="hidden" id="assignmentId" name="assignmentId" value="" />
                <input type="hidden" id="workerId" name="workerId" value="" />
                <div id="commentsform">
                    <p class="label">Cannot submit until you participate!</p>
                </div>
                <input type="hidden" id="ip" name="ip" value="" />
                <input id="submitButton" type="submit" name="Submit" value="Submit HIT" disabled="disabled" />
            </form>
            </p>
        </div>
    </body>
</html>
