// Stimulus set variables
var tot_num_correct_trials = (IN_DEVELOPMENT) ? 2 : 5;
var correct_trials = {"A" : 0, "B" : 0};
var correct_dog_classes;
var dog_tutorial_filepaths;
var tutorial_running = true;
var SKIP_IMAGE = false;

// Active stimulus variables
var trial_i = 0;
var color = [];
var size = 0;
var userId = 0;
var query="";
var user_response;
var activeColor;
var adjustedColor;
var respInt;
var positions = [];
var adjustedSize = [20, 200];
var gap;
var study_1_data;

var breed_key = {};
var dog_breed_key;
var dog_breed_key_inverse;
var example_image_paths = [];

var study_image_div_shift = "-140px";
var tSNE_study_image_div_shift = "-160px";


function setBreedKeys(breed_info) {
    var breeds = breed_info.split("\n");
    var cleaned_breeds = [];
    for (var i=0; i < breeds.length; i++) {
        var breed_str = breeds[i];
        if (breed_str === "") { continue; }
        var breed_split = breed_str.split(":");
        var breed_class = breed_split[0].trim();
        var breed_name = breed_split[1].trim();
        breed_key[breed_class] = breed_name;
    }


    var dog_breed_key_raw = breed_info;
    dog_breed_key_raw = dog_breed_key_raw.split("\n");
    dog_breed_key = {};
    for (var i=0; i<2; i++) {
        var dog = dog_breed_key_raw[i].split(" : ");
        var key = dog[0];
        var val = dog[1];
        dog_breed_key[key] = val;
    }
    dog_breed_key_inverse = {}
    for (var dog_key in dog_breed_key) {
        var dog_val = dog_breed_key[dog_key];
        dog_breed_key_inverse[dog_val] = dog_key;
    }
}

function generateSimulateData(dog_tutorial_filepaths) {
    study_1_data = [];
    for (var i=0; i < 14; i++) {
        var current_img_i = dog_tutorial_filepaths[i];
        var majority_label = current_img_i.split("/");
        var last_index = majority_label.length - 1;
        majority_label = majority_label[last_index].split("__")[0];

        var confidence = Math.random() / 2.0;
        study_1_data.push({"majority_label" : majority_label, "img_confidence" : confidence, "img_correctness" : 0, "path" : dog_tutorial_filepaths[i]})
    }

    for (var i=0; i < 14; i++) {
        var current_img_i = dog_tutorial_filepaths[i+14];
        var majority_label = current_img_i.split("/");
        var last_index = majority_label.length - 1;
        majority_label = majority_label[last_index].split("__")[0];

        var confidence = Math.random() / 2.0 + 0.5;
        study_1_data.push({"majority_label" : majority_label, "img_confidence" : confidence, "img_correctness" : 0, "path" : dog_tutorial_filepaths[i]})
    }
}

function setTutorialImagesList(tutorial_images_list) {
    dog_tutorial_filepaths = [];
    for (var i=0; i < tutorial_images_list.length; i++) {
        var tutorial_image = tutorial_images_list[i].split(APP_DIRECTORY)[1].replace("//", "/");
        tutorial_image = HTTP_TAG + "cu-visualab.org/oracle_query/S2/imgs/" + APP_DIRECTORY + tutorial_image;
        dog_tutorial_filepaths.push(tutorial_image);
    }

    // Simulates data for tutorial visualizations
    generateSimulateData(dog_tutorial_filepaths);

    // Shuffle array
    dog_tutorial_filepaths = shuffle_images(dog_tutorial_filepaths);
}

function setExampleImagesList(example_images_list) {
    for (var img_i=0; img_i < example_images_list.length; img_i++) {
        var example_image_path = example_images_list[img_i].split(APP_DIRECTORY)[1].replace("//", "/");
        example_image_path = HTTP_TAG + "cu-visualab.org/oracle_query/S2/imgs/" + APP_DIRECTORY + example_image_path;
        example_image_paths.push(example_image_path);
    }
    setExampleImages();
}

function init_PHP(main_callBack) {
    logUserToDB(function(logCallback) {
        if (logCallback["success"]) {
            get_PHP_info(function(config_callBack) {
                if (config_callBack["success"]) {
                    setBreedKeys(config_callBack.data.class_breed_info);
                    setExampleImagesList(config_callBack.data.example_images);
                    setTutorialImagesList(config_callBack.data.tutorial_images);
                    main_callBack(true);
                }
                else {
                    main_callBack(false);
                }
            });
        }
        else {
            main_callBack(false);
        }
    });
}

function logUserToDB(callBack) {
    var send_data = {
        "fxn"               : "log_user",
        "dataset"           : APP_DIRECTORY.replace("/", ""),
        "vis"               : VIS_MODE,
        "query_policy"      : QUERY_POLICY
    }
    var dataString = JSON.stringify(send_data);
    $.post("static/php/logUserToDB.php", {data : dataString},
    function(receive_data) {

        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = receive_data;
        }
        callBack(data);
    });
}

function get_PHP_info(callBack) {
    var send_data = {
        "fxn"       : "load_information",
        "dataset"   : APP_DIRECTORY
    }
    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/
    $.post("static/php/tutorial_helper.php", {data : dataString},
    function(receive_data) {

        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = receive_data;
        }
        callBack(data);
    });
}

$(function() {
    init_PHP(function(main_callBack) {
        if (main_callBack) {
            main();
        }
        else {
            console.log(main_callBack);
            console.log("PHP Fail!");
        }
    });
});

function main() {
    // Parse the query variables
    t = new Date();
    query = window.location.search;
    if (query.substring(0, 1) == '?') {
        query = query.substring(1);
    }

    userId = parseInt(query.substring(0, query.indexOf("&")));

    // Establish the display layout
    var d = query.substring(query.indexOf("-d=") + 3);
    $("#stimulus").height(400);
    $("#panel").height(700);
    trial_i = 0;

    window.onbeforeunload = function() {
        // return "";
    }

    window.addEventListener("keyup", function (event) {
        if (event.defaultPrevented) {
            return; // Do nothing if the event was already processed
        }

        switch (event.key) {
        case "f":
        case "F":
            user_response = "A";
            break;
        case "j":
        case "J":
            user_response = "B";
            break;
        default:
            return; // Quit when this doesn't handle the key event.
        }

        // TODO: Do I need to send a response to adapt?
        // TODO: Turn off delay here?
        adapt();

        // Cancel the default action to avoid it being handled twice
        event.preventDefault();
    }, true);


    // Select Photo
    nextImage();
    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.select("#tutorial_image")
            .transition().duration(500)
            .style("opacity", 1.0);

        d3.select("#visualization_div")
            .transition().duration(500)
            .style("opacity", 1.0);
    }, 1000);


}



function shuffle_images(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


function setExampleImages() {
    var img_IDs = ["#dog_A_example_img", "#dog_B_example_img"];
    for (var img_i=0; img_i < example_image_paths.length; img_i++) {
        var example_img = example_image_paths[img_i];
        var img_id = img_IDs[img_i];
        d3.select(img_id).attr("src", example_img);
    }
}


function nextImage() {
    // remove previous image
    d3.select("#tutorial_image").remove();
    d3.select("#tutorial_vis_descript").remove();
    d3.select("#visualization_div").remove();

    // Select next image from list
    var current_img_i = dog_tutorial_filepaths[trial_i].replace("///", "/");

    // Get current image location
    current_img = current_img_i;
    img = current_img;

    // Confidence
    var current_img_confidence = Math.random();

    // Majority Label
    var majority_label_raw = current_img.split("/");
    var last_index = majority_label_raw.length - 1;
    majority_label = majority_label_raw[last_index].split("__")[0];


    // Label for system's image classification
    var label = (dog_breed_key_inverse[majority_label] === "dog_A") ? "Dog Breed A" : "Not Dog Breed A";

    // Append new image
    d3.select("#tutorial_test_image_div").append("img")
        .attr("id", "tutorial_image")
        .attr("src", img)
        .style("opacity", 0.0);

    // Create visualization div
    if (VIS_MODE !== "none") {
        var visualization_div = d3.select("#vis_panel").append("div")
            .attr("id", "visualization_div")
            .style("position", "absolute")
            .style("top", "455px")
            .style("left", "55%")
            .style("opacity", 0.0);

        var description = "<b>How to Read the Visualization</b> <br>";
    }

    // UPDATE INSTRUCTIONS
    // ----------------------------------------------------------------------
    if (VIS_MODE === "none") {
        // TODO: Remove before deployment
        console.log("NONE");
        // Adjust image position
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", 0);

        d3.select("#tutorial_test_image_div").select("p")
            .style("margin-left", "0px");
    }
    else if (VIS_MODE === "numeric") {
        console.log("NUMERIC");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The information on the right presents the system's prediction.<br>";
                description += "The number corresponds to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS (just a number in this case)
        // ---------------------------------------------
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);

        create_numeric_plot(visualization_div, current_img_confidence);

        // ---------------------------------------------
    }
    else if (VIS_MODE === "bar_chart_1") {
        console.log("bar_chart_1");
        // Update Description
        // ------------------------------------------------------------------

        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The visualization on the right presents the system's prediction. You may disagree with it and change the classification.<br>";
                description += "The bar corresponds to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        // Adjust image position
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_bar_chart_1(visualization_div, label, majority_label, current_img_confidence);
        // ----------------------------------------
    }
    else if (VIS_MODE === "bar_chart_2") {
        console.log("bar_chart_2");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The visualization on the right presents the system's prediction. You may disagree with it and change the classification.<br>";
                description += "The bars correspond to the system's certainty in its classification of the image.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart
        create_bar_chart_2(visualization_div, label, majority_label, current_img_confidence);
        // ----------------------------------------
    }
    else if (VIS_MODE === "scatter_plot_1") {
        console.log("scatter_plot_1");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The visualization on the right presents the system's prediction. You may disagree with it and change the classification.<br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The vertical distance in either direction away from the dotted-line represent the system's certainty in its classification.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);
        // Create bar chart

        create_scatter_plot_1(visualization_div, label, majority_label, trial_i, true);
        // ----------------------------------------
    }
    else if (VIS_MODE === "scatter_plot_2") {
        console.log("scatter_plot_2");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The visualization on the right presents the system's prediction. You may disagree with it and change the classification.<br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The vertical distance in either direction away from the dotted-line represent the system's certainty in its classification.<br>";
                description += "The curve over the dots represents the proportion of images for a given level of the system's certainty in classification.<br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", study_image_div_shift);

        visualization_div.style("left", "52%").style("top", "465px");

        create_scatter_plot_2(visualization_div, label, majority_label, trial_i, true);
        // ----------------------------------------
    }
    else if (VIS_MODE === "tSNE") {
        console.log("tSNE");
        // Update Description
        // ------------------------------------------------------------------
        d3.select("#tutorial_visualization_description").append("p")
            .attr("id", "tutorial_vis_descript")
            .html(function() {
                description += "The visualization on the right presents the system's prediction. You may disagree with it and change the classification.<br>";
                description += "Each blue and red dot represents an image in the dataset, and the color corresponds to its classification. <br>";
                description += "The large dot corresponds to the current image. <br>";
                description += "The neighboring dots and their classifications may aid your decision of the current image's true classification. <br>";
                return description;
            });
        // ------------------------------------------------------------------

        // Update VIS
        // ----------------------------------------
        d3.select("#tutorial_test_image_div")
            .style("position", "relative")
            .style("left", tSNE_study_image_div_shift);
        // Create bar chart
        create_tSNE_plot(visualization_div, label, current_img, majority_label, true);
        // ----------------------------------------
    }
    // ----------------------------------------------------------------------
}

function getCorrectAnswer() {
    var current_dog_class = dog_tutorial_filepaths[trial_i];
    var split_string = current_dog_class.split("/");
    var last_index = split_string.length - 1;
    var correct_answer = split_string[last_index].split("_")[1];
    return correct_answer;
}

function logResponse() {
    if (adaptationScreenOn) {
        console.log("Adaption screen on. Wait to click.");
        return;
    }

    // Get the correct answer
    var correct_answer = getCorrectAnswer();

    clearInterval(respInt);

    var error_msg = "Incorrect. Please press the 'F' key if the image appears to be dog breed A and the 'J' key if the image appears to not be dog breed A.";

    if ((correct_trials.A >= tot_num_correct_trials) && (correct_trials.B >= tot_num_correct_trials)) {
        if (user_response == correct_answer) {
            tutorial_running = false;
            d3.select('body').transition().duration(250).style("opacity", 0.4);
            setTimeout(function() {
                alert("Correct. Press 'OK' to exit this window and begin the study.");
                postResponseValues();
                return;
            }, 250);
            return;
        }
        else if (!tutorial_running) {
            return;
        }
        else {
            alert(error_msg);
            correct_trials[correct_answer]--;
            correct_trials[correct_answer] = Math.max(0, correct_trials[correct_answer]);
            return;
        }
    }
    else {
        if (user_response == correct_answer) {
            alert("Correct.");
            correct_trials[correct_answer]++;
        }
        else {
            alert(error_msg);
            correct_trials[correct_answer]--;
            correct_trials[correct_answer] = Math.max(0, correct_trials[correct_answer]);
            return;
        }
    }

    trial_i++;
    adaptationScreen("#tutorial_image");
};



var checked = function($btn) {
    return $btn.val();
};

var postResponseValues = function() {
    window.location = "phase_1.php?" + query;
};
