<?php

    function logUser($SET, $VIS, $POLICY)
    {
        echo json_encode("HERE");

        $projectorer = $_SERVER['QUERY_STRING'];
        
        $time1 = date('Y-m-d H:i:s', time());
        $time2 = date('Y-m-d H:i:s', time());
        // Insert into the id database the id, projectorer, ip, start
        $query = 'INSERT INTO mli_study2.user_data VALUES (0,';
        $query .= '"' . $projectorer . '",'; // TURK ID
        $query .= '"' . $_SERVER['REMOTE_ADDR'] . '",'; // IP
        $query .= '"' . $SET . '",'; // set: example "A"
        $query .= '"' . $VIS . '",';
        $query .= '"' . $POLICY . '",';
        $query .= '"' . $time1 . '", "' . $time2 . '");'; // START AND STOP TIME

        try {
            $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");
            if (!$db) {
                throw new Exception('Error connecting to mysql');
            }
            $result = mysqli_query($db, $query);
            if (!$result) {
                die('Trouble:' . mysqli_error($db) . $query . '<br \>');
            }

            mysqli_close($db);
        }
        catch (Exception $e) {
            echo 'Troubles:<br \>';
        }
    }


    $msg = json_decode($_POST["data"], true);

    if ($msg["fxn"] == "log_user") {
        logUser($msg["dataset"], $msg["vis"], $msg["query_policy"]);
    }
    else {
        echo json_encode("fail");
    }
?>
