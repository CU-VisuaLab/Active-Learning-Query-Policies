<?php $css_sheet_name = "study_style"; ?>
<?php $js_filename = "study"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
    <body>
        <div id="test_panel">
            <div id="Instructions" style="margin-bottom: 50px">
                <p style="display: inline; float: left; width: 30%; padding-left: 15px">Press <b><span style="color: darkred; font-size: xx-large" color="darkred" size="6px">F</span></b> if the image belongs to Dog Breed A.</p>
                <p style="display: inline; float: right; width: 30%; padding-right: 15px">Press <b><span style="color: darkred; font-size: xx-large" color="darkred" size="6px">J</span></b> if the image <b>DOES NOT</b> belong to Dog Breed A.</p>
                <br /><br /><br /><br />
                <p>
                    Look at the image below and determine if it belongs to Dog Breed A or not.<br>
                    If the image belongs to Dog Breed A, press F.<br>
                    If the image <b> does not </b> belong to Dog Breed A, press J.<br>
                    <br>
                    Please answer as quickly and accurately as possible.
                </p>
                <label id="progress"></label> <br /> <label id="loading"></label>
            </div>
            <div id="panel">
                <div id="stimuli">
                    <div id="study_image_div"> </div>
                </div>
            </div>
            <div id="dpi"></div>
        </div>
        <!-- TODO:  static/php/writeStudyResults.php has been put into utils.php - is this an issue now? -->
        <form id="responseForm" method="post" onSubmit="return sendResponseData()" action="static/php/writeStudyResults.php">
            <input type="hidden" id="responses" name="responses"></input>
        </form>
    </body>
</html>
