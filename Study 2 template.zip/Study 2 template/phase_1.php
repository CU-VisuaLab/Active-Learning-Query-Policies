<?php $css_sheet_name = "study_style"; ?>
<?php $js_filename = "phase_1"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
    <body>
        <div id="test_panel">
            <script type="text/javascript" src="static/js/visualizations.js"></script>
            <div id="Instructions" style="margin-bottom: 50px;">
                <p style="display: inline; float: left; width: 30%; padding-left: 15px;">Press <b><span style="color: darkred; font-size: xx-large;" color="darkred" size="6px">F</span></b> to teach the system it is <b>correct</b>.</p>
                <p style="display: inline; float: right; width: 30%; padding-right: 15px;">Press <b><span style="color: darkred; font-size: xx-large;" color="darkred" size="6px">J</span></b> to teach the system it is <b>incorrect</b>.</p>
                <br /><br /><br /><br />
                <p>
                    In this phase, you will act as the system's teacher. <br>
                    An image is presented below, along with the system's classification (Dog Breed A or <b>not</b> Dog Breed A) for that image. <br>
                    Your job is to teach the system it is <b>correct</b> by pressing F, <br>
                    or to tell the system it is <b>incorrect</b> by pressing J.

                    <!-- TODO: Add stuff here particular to visualization condition -->
                    <div id="phase_1_visualization_description"> </div>
                </p>
                <label id="progress"></label> <br /> <label id="loading"></label>
            </div>
            <div id="panel">
                <div id="stimuli">
                    <div id="study_image_div">
                        <div id="image_classification_div">
                            <p id="study_image_classification"></p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="dpi"></div>
        </div>
        <!-- TODO:  static/php/writeStudyResults.php has been put into utils.php - is this an issue now? -->
        <form id="responseForm" method="post">
            <input type="hidden" id="responses" name="responses"></input>
        </form>
    </body>
</html>
