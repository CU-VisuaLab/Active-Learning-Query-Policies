<?php $css_sheet_name = "study_style"; ?>
<?php $js_filename = "transition"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
    <body>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <div id="test_panel">
            <div id="Instructions" style="margin-bottom: 50px; text-align: center;">
                <br /><br /><br /><br />
                <p>
                    You have successfully trained the system.<br> <br>
                    The classifier is now retraining itself based on the inputs you provided in the previous training segment.<br><br>
                </p>
                <div class="container">
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                        </div>
                    </div>
                </div>
                <p id="training_text" style="opacity: 0.0;">
                    The system is now ready to classify images on its own. <br> <br>
                    Click the 'Next' button below to run the classifier and begin the next phase of the experiment.
                </p>
                <br> <br>
                <div id="transition_button_div" style="text-align: center;"> </div>
            </div>
            <div id="dpi"></div>
        </div>
    </body>
</html>
