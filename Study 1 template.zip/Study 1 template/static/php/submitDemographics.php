<?php

	echo $_POST['userId'];
	echo $_POST['vision'];

	$query = 'INSERT INTO mli_test.demographics_data_A1 VALUES (';

	$query .= $_POST['userId'].',';
	$query .= $_POST['age'].',';
	$query .= '"' . $_POST['vision']. '",';
	$query .= '"' . $_POST['cvd'] . '",';
	$query .= $_POST['compTime'].',';
	$query .= '"'.$_POST['education'].'",';
	$query .= '"'.$_POST['display'].'",';
	$query .= '"'.$_POST['gender'].'",';
	$query .= '"'.$_POST['occupation'].'",';
	$query .= $_POST['size'].',';
    $query .= '"'.$_POST['comments'].'")';

	try{
		#$db = fopen('data/'.$id.'.csv', 'w');#
        $db = mysqli_connect("studies.cu-visualab.org","visualab","database1");
		if(!$db){
			throw new Exception('Error connecting to file');
		}
		$result = mysqli_query($db, $query);

		if(!$result){
			die('Trouble:'.mysqli_error($db).$query.'<br \>');
		}

		mysqli_close($db);

	}
	catch(Exception $e){
		die('Trouble:'.mysqli_error($db).'<br \>');
		echo 'Troubles:<br \>';
		echo $e.'<br \>';
	}
?>
