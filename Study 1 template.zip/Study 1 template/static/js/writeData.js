// Code to write a series of results to a CSV
var responseList = [];
var question_number = 0;
function writeData(startDate, endDate, userCorrect) {
    /*
            CREATE TABLE response_data_A1 (
                id INT(10)
                image_name VARCHAR(100),
                user_response VARCHAR(15),
                correct_response VARCHAR(15),
                response_time INT(10)
            );
    */
    var outputLine = [];

    // Set participantId
    // var participantID = (IN_DEVELOPMENT) ? 0 : userId;

    var participantID = userId;

    // participant id
    outputLine.push(participantID);

    // question_number
    outputLine.push(question_number);
    question_number++;

    // question
    outputLine.push("'Is this image Dog Breed A or not Dog Breed A?'");

    // Breed Key
    outputLine.push("'" + dog_breed_key + "'");

    // Current image
    outputLine.push("'" + current_img + "'");

    // User response
    outputLine.push("'" + user_response + "'");

    // User correct
    outputLine.push("'" + userCorrect + "'");

    // Add response time
    var response_time = parseInt(endDate - startDate);
    outputLine.push(response_time);

    // // Add any remaining config params
    // outputLine.push("pixelsToVisAngle:"+parseInt(pixelsToVisualAngle(proximity, inchesToDisplay, dpi) / 2));

    // Write out the file
    var outputData = ("(" + outputLine.join(",") + ")");
    responseList.push(outputData);
};

function pushStudyResultsToDatabase() {
    // Create and HTMML form
    $("#responses").val(responseList.join(","));
    $.ajax({
        type: "POST",
        url: "static/php/logStudyResults.php",
        data: $("#responseForm").serialize(),
        complete: function(e) {
            // console.log(e);
            window.location = "demographics.php?" + userId;
            return true;
        }
    });
};

var toHtml = function(color) {
    if (!color) {
        return "black";
    }
    return "rgba(" + parseInt(255 * color[0]) + "," + parseInt(255 * color[1]) + "," + parseInt(255 * color[2]) + "," + color[3] + ")";
};

var formatDate = function(date) {
    return (date.getMonth() * 100 / 100 + 1) + "/" + date.getDate() + "/" + date.getFullYear() + " " +
        date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds() + "." + date.getMilliseconds();
};

var writeDate = function(date) {
    return (date.getMonth() * 100 / 100 + 1) + "_" + date.getDate() + "_" + date.getFullYear() + "_" +
        date.getHours() + "_" + date.getMinutes() + "_" + date.getSeconds() + "_" + date.getMilliseconds();
};

// Big is generally fixed
var getColorFields = function(first, second) {
    // Get the LCh data
    var big = convertTo(first, COLORTYPE.Lab).slice(0, 3);
    var small = convertTo(second, COLORTYPE.Lab).slice(0, 3);

    return [big, small, big[0] - small[0], big[1] - small[1], big[2] - small[2],
        Math.sqrt((big[0] - small[0]) * (big[0] - small[0]) +
            (big[1] - small[1]) * (big[1] - small[1]) +
            (big[2] - small[2]) * (big[2] - small[2])
        )
    ];
};

var roundForDisplay = function(arr) {
    var out = []
    for (v in arr) {
        out.push(roundVal(arr[v]));
    }
    return out;
};

var roundVal = function(v) {
    if ($.isArray(v)) {
        return roundForDisplay(v);
    }
    if (isNaN(parseFloat(v))) {
        return v;
    }
    return Math.round(v * 1000) / 1000;
};
