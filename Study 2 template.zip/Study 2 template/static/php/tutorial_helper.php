<?php

    function load_information($DATASET_ID) {

        $parent_dir = dirname(__DIR__);

        $upOne = realpath($parent_dir . '/..');
        $upOne = realpath($upOne . '/..');
        $upOne = realpath($upOne . '/..');
        $upOne = realpath($upOne . '/..');

        $tutorial_dir = $upOne . '/imgs/' . $DATASET_ID . '/tutorial/';
        // $tutorial_dir = $upOne . '/imgs/setA1/tutorial/';

        // $tutorial_dir = DATA_PATH . '/tutorial';

        // Get dog breed keys
        $config_filepath = $tutorial_dir . "/dog_breed_key.txt";
        $file_contents = file_get_contents($config_filepath, true);


        // Get example images
        $example_images = array();
        foreach (glob($tutorial_dir . "*.png") as $filename) {
            array_push($example_images, $filename);
        }

        // Get tutorial images
        $tutorial_images_dir = $tutorial_dir . "/dogs/";
        $tutorial_images = array();
        foreach (glob($tutorial_images_dir . "*.png") as $filename) {
            array_push($tutorial_images, $filename);
        }

        $return_data = array(
            "class_breed_info" => $file_contents,
            "example_images" => $example_images,
            "tutorial_images" => $tutorial_images
        );

        echo json_encode($return_data);
    }

    $msg = json_decode($_POST["data"], true);

    if ($msg["fxn"] == "load_information") {
        load_information($msg["dataset"]);
    }
    else {
        echo json_encode("fail");
    }
?>
