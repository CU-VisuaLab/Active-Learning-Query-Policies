// Session variables -- not all of these are implemented
var IN_DEVELOPMENT = false;
var EXPLORE_VISUALIZATIONS = false;

var HTTP_TAG = IN_DEVELOPMENT ? "https://" : "http://";

// VIS MODE
// ---------------------------------------------------------------
var visualization_modes = ["none", "numeric", "bar_chart_1", "bar_chart_2", "scatter_plot_1", "scatter_plot_2", "tSNE"];
// ---------------------------------------------------------------



// Policies
// ---------------------------------------------------------------
// Policy 1: Random
// Policy 2: All low confidence (correctness interspersed)
// Policy 3: All high confidence (correctness interspersed)
// Policy 4: Low to high confidence
// Policy 5: High to low confidence
var query_policies = [
    {"policy": "policy_1", "name" : "P1: Random"},
    {"policy": "policy_2", "name" : "P2: All low confidence (correctness interspersed)"},
    {"policy": "policy_3", "name" : "P3: All high confidence (correctness interspersed)"},
    {"policy": "policy_4", "name" : "P4: Low to high confidence"},
    {"policy": "policy_5", "name" : "P5: High to low confidence"},
];

// ---------------------------------------------------------------


var TRIALS_PER_PARTICIPANT = 25;

var study_1_data;
var sampled_indices;
var userId = "";
var adaptationScreenOn = false; // DO NOT CHANGE

function extract_label(img) {
    var label = img.split("/");
    var last_index = label.length - 1;
    label = label[last_index].trim(".png");
    label = label.split("__")[0];
    var label_class = label.split("_")[1];
    var final_label = (label_class === "A") ? "Dog Breed A" : "Not Dog Breed A";
    return final_label;
}

function extract_image_name(img) {
    var label = img.split("/");
    var last_index = label.length - 1;
    label = label[last_index];
    return label;
}

function initializeData(CURRENT_PHASE, dataCallback) {
    var json_http_tag = HTTP_TAG === "https://" ? "http://" : "https://"    // this is opposite normal. e.g. if HTTP_TAG is http, then this one is https and vice versa
    var condition_data_path = json_http_tag + "cu-visualab.org/oracle_query/S2/condition_data/";
    var CURRENT_PHASE = "training";
    condition_data_path += QUERY_POLICY + "__" + VIS_MODE + "__" + APP_DIRECTORY.replace("/", "") + ".json";
    d3.json(condition_data_path, function(json_data) {
        study_1_data = json_data[CURRENT_PHASE];
        dataCallback("success");
    })
}

function getCorrectAnswer() {
    var sample_i = sampled_indices[trial_i];
    var current_dog_class = study_1_data[sample_i][0];
    var split_string = current_dog_class.split("/");
    var last_index = split_string.length - 1;
    var correct_answer = split_string[last_index].split("__")[0];
    return correct_answer;
}

function getRandomSampleIndices(array) {
    var all_indices = [];
    sampled_indices = [];
    var i = 0;
    for (var i=0; i < array.length; i++) {
        if (QUERY_POLICY === "policy_2" || QUERY_POLICY === "policy_3") {
            if (array[i][1].query) {
                all_indices.push(i);
            }
        }
        else {
            all_indices.push(i);
        }
    }

    all_indices = shuffle_images(all_indices);

    for (var i=0; i < TRIALS_PER_PARTICIPANT; i++) {
        sampled_indices.push(all_indices[i]);
    }

    sampled_indices.sort(function(a, b) {
        return a - b;
    });
}

function adaptationScreen(img_id) {

    d3.selectAll(img_id + ", #visualization_div")
        .transition().duration(500)
        .style("opacity", 0.0);

    setTimeout(function() {
        nextImage();
    }, 700);

    adaptationScreenOn = true;
    setTimeout(function() {
        adaptationScreenOn = false;
        d3.selectAll(img_id + ", #visualization_div")
            .transition().duration(200)
            .style("opacity", 1.0);
    }, 750);
}

function getUserId(callBack) {
    $.ajax({
        url: 'static/php/utils.php',
        data: {action: 'fetchUserId'},
        type: 'post',
        success: function(response) {
            userId = parseInt($.parseJSON(response));
            callBack("success");
        }
    });
}

function loadConditionParamScript() {
    var script = document.createElement('script');
    script.onload = function() {
        console.log("Loaded condition params!");
        console.log("Policy: " + QUERY_POLICY);
        console.log("VIS: " + VIS_MODE);
        console.log("Dataset: " + APP_DIRECTORY);
    }
    script.src = "condition_params.js";
    document.head.appendChild(script);
}


function writeConditionParamsJS(policy, vis, app_dir, callBack) {
    var send_data = {
        "fxn" : "writeInitializerJS",
        "policy"        : policy,
        "vis"           : vis,
        "dataset"       : app_dir
    }

    var dataString = JSON.stringify(send_data);
    // REF: http://www.prodevtips.com/2008/08/15/jquery-json-with-php-json_encode-and-json_decode/

    $.post("static/php/writeConditionParams.php", {data : dataString},
    function(receive_data) {
        var data = {};
        try {
            var obj = $.parseJSON(receive_data);
            data["data"] = obj;
            data["success"] = true;
        }
        catch (e) {
            data["success"] = false;
        }
        callBack(data);
    });
}
