<?php $css_sheet_name = "study_style"; ?>
<?php $js_filename = "post_survey_questions"; ?>
<?php $page_title = "Evaluating Active Learning Oracle Querying Policies"; ?>
<?php require("header.php"); ?>
<body>
    <form id="responseForm" method="post">
        <input type="hidden" id="responses" name="responses"></input>
    </form>

    <div class="wrap_2">
        <h1 class=likert-header> Post Survey Questionnaire</h1>
        <h1 class="likert-header_2">Below is a list of statement for evaluating trust between people and automation. There are several scales for you to rate intensity of your feeling of trust, or your impression of the system while operating a machine. Please click the button which best describes your feeling or your impression.</h1>
        <form id="questionnaireForm">
            <input type="hidden" name="userId" id="userId"/>
            <label class="statement">The system is deceptive.</label>
            <ul class='likert_2' id="likert_ul_1">
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="1" onClick="styleIt('1')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="2" onClick="styleIt('1')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="3" onClick="styleIt('1')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="4" onClick="styleIt('1')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="5" onClick="styleIt('1')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="6" onClick="styleIt('1')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_1" value="7" onClick="styleIt('1')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I am confident in the system's decisions.</label>
            <ul class='likert_2' id="likert_ul_2">
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="1" onClick="styleIt('2')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="2" onClick="styleIt('2')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="3" onClick="styleIt('2')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="4" onClick="styleIt('2')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="5" onClick="styleIt('2')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="6" onClick="styleIt('2')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_2" value="7" onClick="styleIt('2')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I am suspicious of the system's decisions.</label>
            <ul class='likert_2' id="likert_ul_3">
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="1" onClick="styleIt('3')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="2" onClick="styleIt('3')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="3" onClick="styleIt('3')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="4" onClick="styleIt('3')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="5" onClick="styleIt('3')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="6" onClick="styleIt('3')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_3" value="7" onClick="styleIt('3')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I am wary of the system.</label>
            <ul class='likert_2' id="likert_ul_4">
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="1" onClick="styleIt('4')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="2" onClick="styleIt('4')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="3" onClick="styleIt('4')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="4" onClick="styleIt('4')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="5" onClick="styleIt('4')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="6" onClick="styleIt('4')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_4" value="7" onClick="styleIt('4')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">The system is too confident in it's own decisions.</label>
            <ul class='likert_2' id="likert_ul_5">
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="1" onClick="styleIt('5')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="2" onClick="styleIt('5')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="3" onClick="styleIt('5')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="4" onClick="styleIt('5')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="5" onClick="styleIt('5')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="6" onClick="styleIt('5')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_5" value="7" onClick="styleIt('5')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">The system behaves in a dishonest manner.</label>
            <ul class='likert_2' id="likert_ul_6">
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="1" onClick="styleIt('6')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="2" onClick="styleIt('6')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="3" onClick="styleIt('6')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="4" onClick="styleIt('6')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="5" onClick="styleIt('6')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="6" onClick="styleIt('6')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_6" value="7" onClick="styleIt('6')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">The system makes too many mistakes.</label>
            <ul class='likert_2' id="likert_ul_7">
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="1" onClick="styleIt('7')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="2" onClick="styleIt('7')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="3" onClick="styleIt('7')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="4" onClick="styleIt('7')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="5" onClick="styleIt('7')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="6" onClick="styleIt('7')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_7" value="7" onClick="styleIt('7')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">The system's output is trustworthy.</label>
            <ul class='likert_2' id="likert_ul_8">
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="1" onClick="styleIt('8')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="2" onClick="styleIt('8')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="3" onClick="styleIt('8')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="4" onClick="styleIt('8')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="5" onClick="styleIt('8')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="6" onClick="styleIt('8')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_8" value="7" onClick="styleIt('8')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I feel like my training of the system had a positive impact on its performance.</label>
            <ul class='likert_2' id="likert_ul_9">
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="1" onClick="styleIt('9')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="2" onClick="styleIt('9')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="3" onClick="styleIt('9')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="4" onClick="styleIt('9')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="5" onClick="styleIt('9')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="6" onClick="styleIt('9')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_9" value="7" onClick="styleIt('9')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">The system is reliable.</label>
            <ul class='likert_2' id="likert_ul_10">
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="1" onClick="styleIt('10')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="2" onClick="styleIt('10')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="3" onClick="styleIt('10')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="4" onClick="styleIt('10')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="5" onClick="styleIt('10')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="6" onClick="styleIt('10')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_10" value="7" onClick="styleIt('10')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I can trust the system.</label>
            <ul class='likert_2' id="likert_ul_11">
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="1" onClick="styleIt('11')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="2" onClick="styleIt('11')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="3" onClick="styleIt('11')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="4" onClick="styleIt('11')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="5" onClick="styleIt('11')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="6" onClick="styleIt('11')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_11" value="7" onClick="styleIt('11')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I feel that I trained the system well.</label>
            <ul class='likert_2' id="likert_ul_12">
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="1" onClick="styleIt('12')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="2" onClick="styleIt('12')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="3" onClick="styleIt('12')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="4" onClick="styleIt('12')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="5" onClick="styleIt('12')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="6" onClick="styleIt('12')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_12" value="7" onClick="styleIt('12')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
            <label class="statement">I feel like I understood the system's confidence.</label>
            <ul class='likert_2' id="likert_ul_13">
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>1 <br> (not at all)</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>2</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>3</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>4</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>5</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>6</label>
                </li>
                <li>
                    <input type="radio" name="likert_questionnaire_13" value="1" onClick="styleIt('13')">
                    <label>7 <br> (extremely)</label>
                </li>
            </ul>
        </form>
    </div>
</body>
</html>
