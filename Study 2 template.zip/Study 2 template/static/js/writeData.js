// Code to write a series of results to a CSV
var responseList = [];
var question_number = 0;
function writeData_phase_1(startDate, endDate, majority_label) {
    /*
        CREATE TABLE response_data_phase_1 (
            userId INT(10),
            question_number INT(10),
            breed_key VARCHAR(100),
            image_name VARCHAR(100),
            user_response VARCHAR(15),
            majority_label VARCHAR(15),
            response_time INT(10)
        );
    */
    var outputLine = [];

    // participant id
    outputLine.push(userId);

    // question_number
    outputLine.push(question_number);
    question_number++;

    // Breed Key
    outputLine.push("'" + dog_breed_key_raw + "'");

    // Query policy
    outputLine.push("'" + QUERY_POLICY + "'");

    // Visualization mode
    outputLine.push("'" + VIS_MODE + "'");

    // Current image
    outputLine.push("'" + current_img + "'");

    // User response
    outputLine.push("'" + user_response + "'");

    // majority_label
    outputLine.push("'" + majority_label + "'");

    // Add response time
    var response_time = parseInt(endDate - startDate);
    outputLine.push(response_time);

    // Write out the file
    var outputData = ("(" + outputLine.join(",") + ")");

    responseList.push(outputData);
};

function writeData_phase_2(startDate, endDate, majority_label, confidence_scores) {
    /*
        CREATE TABLE response_data_phase_2 (
            userId INT(10),
            question_number INT(10),
            breed_key VARCHAR(100),
            query_policy VARCHAR(100),
            visualization_mode VARCHAR(100),
            image_name VARCHAR(100),
            user_response VARCHAR(15),
            majority_label VARCHAR(15),
            user_agreement INT(10),
            user_confidence INT(10),
            system_confidence INT(10),
            response_time INT(10)
        );
    */
    var outputLine = [];

    // participant id
    outputLine.push(userId);

    // question_number
    outputLine.push(question_number);
    question_number++;

    // Breed Key
    outputLine.push("'" + dog_breed_key_raw + "'");

    // Query policy
    outputLine.push("'" + QUERY_POLICY + "'");

    // Visualization mode
    outputLine.push("'" + VIS_MODE + "'");

    // Current image
    outputLine.push("'" + current_img + "'");

    // System majority_label of image
    outputLine.push("'" + majority_label + "'");

    // User response, confidence, trust, etc.
    for (var i in confidence_scores) {
        outputLine.push("'" + confidence_scores[i] + "'");
    }

    // Add response time
    var response_time = parseInt(endDate - startDate);
    outputLine.push(response_time);

    // Write out the file
    var outputData = ("(" + outputLine.join(",") + ")");

    responseList.push(outputData);
};

function pushStudyResultsToDatabase(phase_num, query) {

    var phase_php_url = (phase_num === "phase_1") ? "static/php/logStudyResults_phase_1.php" : "static/php/logStudyResults_phase_2.php";
    var next_window = (phase_num === "phase_1") ? "transition.php?" + query : "post_survey_questions.php?" + query;
    // Create and HTMML form
    $("#responses").val(responseList.join(","));
    $.ajax({
        type: "POST",
        url: phase_php_url,
        data: $("#responseForm").serialize(),
        complete: function(e) {
            window.location = next_window;
            return true;
        }
    });
};

var toHtml = function(color) {
    if (!color) {
        return "black";
    }
    return "rgba(" + parseInt(255 * color[0]) + "," + parseInt(255 * color[1]) + "," + parseInt(255 * color[2]) + "," + color[3] + ")";
};

var formatDate = function(date) {
    return (date.getMonth() * 100 / 100 + 1) + "/" + date.getDate() + "/" + date.getFullYear() + " " +
        date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds() + "." + date.getMilliseconds();
};

var writeDate = function(date) {
    return (date.getMonth() * 100 / 100 + 1) + "_" + date.getDate() + "_" + date.getFullYear() + "_" +
        date.getHours() + "_" + date.getMinutes() + "_" + date.getSeconds() + "_" + date.getMilliseconds();
};

// Big is generally fixed
var getColorFields = function(first, second) {
    // Get the LCh data
    var big = convertTo(first, COLORTYPE.Lab).slice(0, 3);
    var small = convertTo(second, COLORTYPE.Lab).slice(0, 3);

    return [big, small, big[0] - small[0], big[1] - small[1], big[2] - small[2],
        Math.sqrt((big[0] - small[0]) * (big[0] - small[0]) +
            (big[1] - small[1]) * (big[1] - small[1]) +
            (big[2] - small[2]) * (big[2] - small[2])
        )
    ];
};

var roundForDisplay = function(arr) {
    var out = []
    for (v in arr) {
        out.push(roundVal(arr[v]));
    }
    return out;
};

var roundVal = function(v) {
    if ($.isArray(v)) {
        return roundForDisplay(v);
    }
    if (isNaN(parseFloat(v))) {
        return v;
    }
    return Math.round(v * 1000) / 1000;
};
