var GRID_PAD = 50;

// Drawing constants
var COLORTYPE = {
	HSV: 	{value: 0, mins: [0, 0, 0, 0], 	maxs:[360, 100, 100, 1], name: "HSV", step: 1},
	Lab: 	{value: 1, mins: [0, -128, -128, 0], 	maxs: [100, 128, 128, 1], name: "Lab", step: 1},
	LCh: 	{value: 2, mins: [0, 0, 0, 0], 	maxs: [100, 100, 360, 1], name: "LCh", step: 1},
	Alpha: 	{value: 3, mins: [0, 0, 0, 0], 	maxs: [1, 0, 0, 0], name: "Alpha", step: 0.01}
};

// Convert from a visual angle to pixel values to compute sizes
var visualAngleToPixels = function(angleDegrees, inchesToDisplay, approxDpi) {
	var angleRadians = angleDegrees * Math.PI / 180.0;
	return inchesToDisplay * Math.tan(angleRadians / 2.0) * approxDpi;
};

// Convert from a pixel size to a visual angle in degrees
var pixelsToVisualAngle = function(pixels, inchesToDisplay, approxDpi) {
	var sizeInches = 2 * pixels / approxDpi; 		// 2 is to account for pixels being a radius
	return 2 * Math.atan2(sizeInches, (2 * inchesToDisplay)) * (180 / Math.PI);
};


var adapt = function(record) {

	// Set the screen to grey to avoid afterimage effects
	// TODO: Fix this?
	d3.select("div #stimuli").select("svg")
		.append("rect")
		.attr("width", function() {
			return (2*proximity + 2 * GRID_PAD + 4 * LARGEST_SIZE);

		})
		.attr("height", function() {
			return (2*proximity + 2 * GRID_PAD + 2 * LARGEST_SIZE);
		})
		.attr("x",0)
		.attr("fill", "rgb(200,200,200)");

	if (record) {
		// TODO: Update here!
		// Record the response -- this is a global variable
		// activeColor.color = adjustedColor.color;
		// activeColor.position = 0;
		// activeColor.fixedSide = (positions[0][POS + 1] == -1) ? "left" : "right";
	}

	//clearInterval(respInt);
	endTime = new Date();
	// respInt = setInterval(logResponse, 5);
	logResponse();
}
