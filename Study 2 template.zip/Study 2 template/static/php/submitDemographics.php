<?php

	$query = 'INSERT INTO mli_study2.demographics VALUES (';

	$query .= $_POST['userId'].',';
	$query .= $_POST['age'].',';
	$query .= '"' . $_POST['vision']. '",';
	$query .= '"' . $_POST['cvd'] . '",';
	$query .= $_POST['compTime'].',';
	$query .= '"'.$_POST['education'].'",';
	$query .= '"'.$_POST['data_analysis_experience'].'",';
	$query .= '"'.$_POST['ml_experience'].'",';
	$query .= '"'.$_POST['display'].'",';
	$query .= '"'.$_POST['gender'].'",';
	$query .= '"'.$_POST['occupation'].'",';
	$query .= $_POST['size'].',';
    $query .= '"'.$_POST['comments'].'")';

	try {
        $db = mysqli_connect("studies.cu-visualab.org", "visualab", "database1");
		if(!$db){
			throw new Exception('Error connecting to file');
		}
		$result = mysqli_query($db, $query);

		if(!$result){
			die('Trouble:'.mysqli_error($db).$query.'<br \>');
		}

		mysqli_close($db);

	}
	catch(Exception $e){
		die('Trouble:'.mysqli_error($db).'<br \>');
		echo 'Troubles:<br \>';
		echo $e.'<br \>';
	}
?>
