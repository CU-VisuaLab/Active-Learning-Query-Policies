var APP_DIRECTORY='setA1/';
var QUERY_POLICY='policy_1';
var VIS_MODE='none';
